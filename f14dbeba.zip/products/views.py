from django.views.generic import DetailView, ListView
from .models import Product


class ProductListView(ListView):
    template_name = 'products/list.html'
    context_object_name = 'products'

    def get_queryset(self):
        qs = Product.objects.select_related('category').all().order_by('name')
        q = self.request.GET.get('q')
        cat = self.request.GET.get('category')
        if q:
            qs = qs.filter(name__icontains=q)
        if cat:
            qs = qs.filter(category_id=cat)
        return qs


class ProductDetailView(DetailView):
    template_name = 'products/detail.html'
    model = Product
    context_object_name = 'product'

