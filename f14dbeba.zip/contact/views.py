from django.urls import reverse_lazy
from django.views.generic import CreateView
from .forms import ContactForm


class ContactFormView(CreateView):
    template_name = 'contact/contact.html'
    form_class = ContactForm
    success_url = reverse_lazy('contact:form')

    def form_valid(self, form):
        response = super().form_valid(form)
        form.instance.save()
        return response

