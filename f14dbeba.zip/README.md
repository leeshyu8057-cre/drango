BioChem bioww — Django + Docker (Ubuntu 22.04)

Overview
- New clean project folder `bioww` rebuilt from current code, with Products + Contact apps, admin CSV import and ChemicalBook sync stubs.
- Dockerized for Ubuntu 22.04 hosts (Docker/Compose). Uses SQLite by default.
 - Includes batch scraping command with polite scraping (retries, rate limiting, robots.txt respect). Transport hook provided for advanced environments.

Quickstart (Ubuntu 22.04)
- Install Docker + Compose plugin
  - sudo apt update && sudo apt install -y docker.io docker-compose-plugin
  - sudo usermod -aG docker $USER && newgrp docker
- Build and run
  - cd bioww
  - docker compose up --build
  - Open http://127.0.0.1:8000
- Create admin
  - docker compose exec web python manage.py createsuperuser

Local (no Docker)
- cd bioww
- python3 -m venv .venv && . .venv/bin/activate
- pip install -r requirements.txt
- python manage.py migrate
- python manage.py runserver 0.0.0.0:8000

Admin Features
- CSV Import: Products list → top-right buttons → "⇪ 匯入商品"
- ChemicalBook Sync: Products list → "🤖 爬蟲同步"

Batch Scraping (polite)
- Read URLs from a file and save/update Products.
- With Docker:
  - docker compose exec web python manage.py scrape_products --urls-file /app/urls.txt --concurrency 4 --delay 1.0
- Locally:
  - python manage.py scrape_products --urls-file urls.txt --concurrency 4 --delay 1.0

Transport Hook (advanced)
- The scraper exposes a pluggable transport interface for HTTP requests.
- By default it uses requests with retries and standard headers; it does not attempt to bypass bot protections (Cloudflare/Akamai/JA3 spoofing).
- If you have your own compliant transport, implement `get_transport()` in `products/scraper.py` to return a session-like object.

Files
- Dockerfile: python image, installs deps, runs via gunicorn
- docker-compose.yml: mounts source, auto-migrate and collectstatic on start
- entrypoint.sh: migrate + collectstatic + start server
- management command: products/management/commands/scrape_products.py
