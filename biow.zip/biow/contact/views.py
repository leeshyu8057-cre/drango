from django.shortcuts import render


def contact_view(request):
    message_sent = False

    if request.method == 'POST':
        # 這裡可以串接 email 或 CRM，暫時先顯示成功訊息
        message_sent = True

    return render(request, 'contact/contact.html', {'message_sent': message_sent})
