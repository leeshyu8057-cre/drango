from django.test import TestCase
from django.urls import reverse


class ContactViewTests(TestCase):
    def test_get_request_renders_contact_form(self):
        response = self.client.get(reverse('contact:contact'))
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'contact/contact.html')
        self.assertContains(response, '聯絡我們')

    def test_post_request_sets_success_flag(self):
        response = self.client.post(
            reverse('contact:contact'),
            {
                'name': 'Alice',
                'email': 'alice@example.com',
                'message': 'Need COA',
            },
            follow=True,
        )
        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.context['message_sent'])
        self.assertContains(response, '感謝您的留言')
