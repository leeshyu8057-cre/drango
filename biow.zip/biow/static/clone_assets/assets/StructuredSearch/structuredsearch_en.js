﻿var searchType = GetCookie('searchType');
if (!searchType) searchType = 2;
$("input[name='it_ketchertype']").click(function () {
    //SetCookie('searchType', $(this).val());
});
var ketcher = null;
var hasimg = false;
var doing = false;
var imgname = "structrure";
function addimg(img) {
    $('#imgshow').attr("src", img);
    hasimg = true;
    loadmolbyimg();
}

function loadmolbycas() {
    var cas = $('#cas').val();
    if (cas.trim() == "") {
        tusiMsg('Please enter Cas!');
    }
    else if (!isCasNo(cas)) {
        tusiMsg('The input of Cas is incorrect!');
    } else {
        loadMolCasAndImg(cas, 1);
    }
}

function loadmolbyimg() {
    if (!hasimg) {
        tusiMsg('Please select the image to convert first!');
        return;
    }
    if (doing) {
        tusiMsg('Converting, please wait...')
        return;
    }
    var data = $('#imgshow').attr('src');
    loadMolCasAndImg(data, 2);
}

function base64ToFile(dataurl, filename) { //base64 to file
    var arr = dataurl.split(','),
        mime = arr[0].match(/:(.*?);/)[1],
        bstr = atob(arr[1]),
        n = bstr.length,
        u8arr = new Uint8Array(n);
    while (n--) {
        u8arr[n] = bstr.charCodeAt(n);
    }
    return new File([u8arr], filename, { type: mime });
}

function ImgToConvert() {
    getImg(function (image) {
        var can = imgToCanvas(image),
            imgshow = document.getElementById('imgshow')
        imgshow.setAttribute('src', canvasToImg(can))

    })

}
//  image Convert canvas object
function imgToCanvas(image) {
    var canvas = document.createElement('canvas')
    canvas.width = image.width
    canvas.height = image.height
    canvas.getContext('2d').drawImage(image, 0, 0)
    return canvas
}
//canvas Convert image
function canvasToImg(canvas) {
    var array = ['image/webp', 'image/jpeg', 'image/jpg', 'image/png'];
    var src = canvas.toDataURL(array[3])
    return src;
}
function changeImage2(dataImg, callback) {
    let self = this;
    var base64Img = document.createElement("base64Img"),
        canvas = document.createElement("canvas"),
        context = canvas.getContext("2d");
    // Create Image 
    var img = new Image();
    img.src = dataImg;
    img.addEventListener(
        "load",
        function () {
            //Image to canvas 
            canvas.width = img.width;
            canvas.height = img.height;
            context.drawImage(img, 0, 0);

            //  canvas background set white
            var imageData = context.getImageData(
                0,
                0,
                canvas.width,
                canvas.height
            );
            for (var i = 0; i < imageData.data.length; i += 4) {
                //rgb>25 y set 0
                if (
                    imageData.data[i] > 250 &&
                    imageData.data[i + 1] > 250 &&
                    imageData.data[i + 2] > 250
                ) {
                    imageData.data[i + 3] = 0;
                }
            }
            context.putImageData(imageData, 0, 0);
            self.baseImg = canvas.toDataURL("image/png").slice(22);//base64
            if (typeof callback !== undefined) {
                if (callback) callback(self.baseImg);
            }
        },
        false
    );
}
//get image
function getImg(fn) {
    var imgFile = new FileReader();
    clearFile();
    if (document.getElementById('imgfile').files[0] == undefined) {
        var dataUrl = $('#imgshow').attr('src');
        let finalFile = base64ToFile(dataUrl, imgname)

        try {
            imgFile.onload = function (e) {
                var image = new Image()
                image.src = e.target.result //base64
                image.onload = function () {
                    fn(image)
                }
            }
            imgFile.readAsDataURL(finalFile)
        } catch (e) {
            alert('Please upload pictures!' + e)
        }
    }
}
function clearFile() {
    var obj = document.getElementById("imgfile");
    obj.outerHTML = obj.outerHTML;

}

$(document).on("change", "#imgfile", function () {
    if (typeof (FileReader) != "undefined") {
        var reader = new FileReader();
        reader.onload = function (e) {
            var img = e.target.result;
            addimg(img);
        }
        if ($(this)[0].files[0]) reader.readAsDataURL($(this)[0].files[0]);
    } else { alert("This browser does not support FileReader."); }

});


function getKetcher() {
    if (ketcher) return ketcher;
    var frame = null;

    if ('frames' in window && 'ketcherFrame' in window.frames) {
        frame = window.frames['ketcherFrame'];
    } else {
        return null;
    }
    if ('window' in frame) {
        ketcher = frame.window.ketcher;
    }
    return ketcher;
}


//ketcher query
async function clickketcher() {
    var smile = null;
    var mol = null;
    var ketcher = getKetcher();
    var result = ketcher.getSmiles();
    await result.then(res => {
        document.getElementById("smiles").value = res;
    });
    result = ketcher.getMolfile();
    await result.then(res => {
        document.getElementById("mol").value = res;
    });

    try {
        smile = document.getElementById("smiles").value;
        mol = document.getElementById("mol").value;

        $.ajax({
            url: "/StructuredSearch/WriteCookie",
            type: "post",
            async: false,
            data: { key: "Ketcher", mol: mol, smile: smile },
            success: function (data) {

            }
        });
    } catch (ex) {
        tusiMsg('The structural diagram is incorrect, please redraw it!');
        return false;
    }
    if (smile == "") {
        tusiMsg('Please draw the structural formula first before searching!');
        return false;
    }
    var ketchertype = document.getElementsByName("it_ketchertype");
    var similarity;
    var searchtype;
    for (var i = 0; i < ketchertype.length; i++) {
        if (ketchertype[i].checked) {
            similarity = ketchertype[i].value;
            searchtype = ketchertype[i].getAttribute("data-searchType");
            break;
        }
    }
    document.getElementById("searchType").value = similarity;
    //window.location.href = "smileproducts/" + searchtype + "/" + similarity + "/" + encodeURIComponent(smile.replace(/\\/g, "_").replace(/[/]/g, "$")) + "_en.htm?page=1&show=grid";
    window.location.href = "smileproducts/" + searchtype + "/" + similarity + "/productlist_en.htm?page=1&show=grid";

}

function loadMolCasAndImg(data, key) {
    if (doing) return;
    doing = true;
    //$('.tj_xcx_bg').show();
    //$('.tj_xcx').show();
    var molStr = null;
    var methodname = "";
    if (key == 1)
        methodname = "GetStructureOfCas";
    else if (key == 2)
        methodname = "GetStructureOfImg";
    $.ajax({
        url: "/StructuredSearch/" + methodname,
        //async: false,
        cahce: false,
        type: "post",
        datatype: "json",
        data: { data: data },
        success: function (data) {
            doing = false;
            if (data) {
                if (data.indexOf('END') != -1) {
                    initialMolecule = molStr;
                    var ketcher = getKetcher();
                    ketcher.setMolecule(data);
                    //document.JME.readGenericMolecularInput(data);
                }
            } else {
                tusiMsg('Structural conversion failed!');
            }
        }
    });
}
function loadMol2() {
    window.setTimeout(function () {
        loadMol();
    }, 100);
}

function loadMol() {
    var molStr = null;
    molStr = $("#h_moltxt").val();
    if (!molStr) {
        $.ajax({
            url: "/StructuredSearch/ReadCookie",
            async: false,
            cahce: false,
            type: "post",
            data: { key: "Ketcher" },
            success: function (data) {
                molStr = decodeURIComponent(data);
            }
        });
    }
    initialMolecule = molStr;
    var ketcher = getKetcher();
    ketcher.setMolecule(initialMolecule);
    $("#cas").focus();
}


radioinit('it_ketchertype', searchType);

$('#ketcherFrame').on('load', function () {
    setTimeout(function () {
        var mol = $('#mol').val();
        if (mol != '') {
            getKetcher().setMolecule("\n" + mol.ReplaceAll('null', ''));
        }
    }, 300);
});


$(function () {
    $("#casConvert").click(function () {
        $("#cas_input").val("");
        $("div[data-cas-box='true']").show();
    });

    $("a[data-cas-box-close='true']").click(function () {
        $("#cas_input").val("");
        $("div[data-cas-box='true']").hide();
    });

    $("#castostructured").click(function () {
        var cas = $("#cas_input").val();
        if (cas.trim() == "") {
            alert("Please enter your CAS number!");
            return;
        }

        $("#cas").val(cas);
        loadmolbycas();
        $("a[data-cas-box-close='true']").click();
    });
})