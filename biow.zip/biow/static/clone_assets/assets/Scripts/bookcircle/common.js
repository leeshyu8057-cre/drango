﻿var tid = 0;
getUrl = function (name, value, url) {
    var search = url || window.location.search;
    search = search.substr(search.indexOf("?"), search.length);
    value = encodeURIComponent(value);
    if (search) {
        var searchs = search.replace(/\?/g, "").split("&");
        var repeater = false;
        for (var i = 0; i < searchs.length; i++) {
            if (searchs[i].indexOf(name + "=") == 0) {
                searchs[i] = name + "=" + value;
                repeater = true;
                break;
            }
        }
        if (!repeater) {
            searchs.push(name + "=" + value);
        }
        return window.location.href.substring(0, window.location.href.indexOf("?") + 1) + searchs.join("&");
    }
    else {
        return window.location.href + "?" + name + "=" + value;
    }
};

removeUrl = function (name, url) {

    var search = url || window.location.search;
    if (search) {
        var searchs = search.replace(/\?/g, "").split("&");
        var index = -1;
        for (var i = 0; i < searchs.length; i++) {
            if (searchs[i].indexOf(name + "=") == 0) {
                index = i;
                break;
            }
        }
        if (index > -1) {
            searchs.splice(index, 1);
        }
        if (searchs.length > 0) {
            return window.location.href.replace(search, "?" + searchs.join("&"));
        }
        else {
            return window.location.href.replace(search, "");
        }
    }
}

removeUrlSearch = function (name, url) {
    var patter = "[&|?]" + name + "=[^&#]+";
    return url.replace(new RegExp(patter), "");
};

getSearchParameters = function () {
    var search = window.location.search;
    var parameters = [];
    if (search) {
        var searchs = search.replace(/\?/g, "").split("&");

        //字母或字母+数字为动态查询条件，两个字母的为固定查询
        for (var i = 0; i < searchs.length; i++) {
            var parameter = searchs[i].split("=");
            var key = parameter[0];
            var name = decodeURIComponent(parameter[1]);
            var value = name;

            var patter = /^(?:page)$/i;
            if (!patter.test(key)) {
                parameters.push({ key: key, name: name, value: value });
            }
        }
    }
    return parameters;

}

getCookie = function (name) {
    var arr, reg = new RegExp("(^| )" + name + "=([^;]*)(;|$)");
    if (arr = document.cookie.match(reg)) {
        return unescape(arr[2]);
    } else {
        return null;
    }
}

function copyToClipboard(text) {
    const el = document.createElement('input')
    el.setAttribute('value', text)
    document.body.appendChild(el)
    el.select()
    document.execCommand('copy')
    document.body.removeChild(el)
}

function uuid() {
    var s = [];
    var hexDigits = "0123456789abcdef";
    for (var i = 0; i < 36; i++) {
        s[i] = hexDigits.substr(Math.floor(Math.random() * 0x10), 1);
    }
    s[14] = "4";
    s[19] = hexDigits.substr((s[19] & 0x3) | 0x8, 1);
    s[8] = s[13] = s[18] = s[23] = "-";

    var uuid = s.join("");
    return uuid;
}
var storageSet = function (key, value) {
    localStorage.setItem(key, JSON.stringify(value));
}

var storageGet = function (key) {
    return JSON.parse(localStorage.getItem(key));
}
