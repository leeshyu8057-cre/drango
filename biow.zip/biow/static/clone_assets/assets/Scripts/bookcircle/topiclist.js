﻿var up_session = "up";
var upArr = [];
var page = 1;
function loadTopic() {
    if (isLoad) {
        return;
    }
    if (lastPage) {
        return;
    }
    isLoad = true;
    var searchJson = {};
    searchJson.Sort = $("#sort").val();
    searchJson.CategoryId = $("#categoryId").val();
    searchJson.Keyword = $("#keyword").val();
    searchJson.PageIndex = page;
    searchJson.TId = $("#tid").val();
    $.ajax({
        type: "GET",
        contentType: "application/json",
        url: url,
        data: { searchJson: JSON.stringify(searchJson) },
        dataType: "json",
        success: function (result) {
            isLoad = false;
            if (result.length > 0) {
                var topics = result;
                var html = ``;
                //pageCount = result.Pages;
                for (var i = 0; i < topics.length; i++) {
                    var item = topics[i];
                    if (topics[i].CategoryId == 3) {
                        html += `<div class="panew bottom">`;
                        html += `<div class="panel">`;
                        html += `    <div class="panelt">`;
                        html += `        <a class="ptimg" href="` + $("#url1").val() + item.TopicID + `.htm"><img src="` + (item.LogoUrl == "" ? "/Content/images/tox.png" : "https://img.chemicalbook.com/" + item.LogoUrl) + `"></a>`;
                        html += `    </div>`;
                        html += `    <div class="panelc">`;
                        html += `        <div class="ptname">`;
                        html += `            <div class="ptp">` + item.CompanyShortName + `<a class="pta" href="` + $("#url1").val() + item.TopicID + `.htm">@` + item.CompanyName + `</a></div>`;
                        html += `        </div>`;
                        if (item.MetaDecription == "") {
                            html += `        <div class="pctxt"></div>`;
                        }
                        else {
                            html += `        <div class="pctxt"><a href="` + $("#url2").val().replace("{topicid}", item.TopicID) + `">` + item.MetaDecription + `</a></div>`;
                        }
                        if (item.Resources != null && item.Resources.length > 0) {
                            var video = "";
                            var videoImg = "";
                            for (var i = 0; i < item.Resources.length; i++) {
                                if (item[i].ResourceType == 3) {
                                    video = item[i].ResourceUrl;
                                }
                                if (item[i].ResourceType == 2) {
                                    videoImg = item[i].ResourceUrl;
                                }
                            }
                            html += `   <div class="sp">`;
                            html += `        <video poster="` + videoImg + `" src="` + video + `" style="width:100%;height:225px" controls></video>`
                            //html += `            <div data-type="video" style="width:auto;height:200px;" id="` + ("video" + item.TopicID) + `" data-id="` + item.TopicID + `" data-src="` + item.Resources[0].ResourceUrl + `"></div>`;
                            html += `     </div>`;
                        }
                        html += `            <div class="updatetime">` + item.DateTimeDescribe + `</div>`;
                        html += `    </div>`;
                        html += `    <div class="panelb">`;
                        html += `        <span data-forward="true" data-id="` + item.TopicID + `" data-forwardcount="` + item.ForwardCount + `" data-share-title="` + item.MetaTitle + `" data-share-summary="` + item.MetaDecription + `" data-share-img=""><i class="zf"></i>` + item.ForwardCount + `</span>`;
                        html += `        <span data-reply="true" data-id="` + item.TopicID + `" data-replycount="` + item.ReplyCount + `"><i class="pl"></i>` + item.ReplyCount + `</span>`;
                        html += `        <span data-support="true" data-id="` + item.TopicID + `" data-supportcount="` + item.SupportCount + `"><i class="dz"></i>` + item.SupportCount + `</span>`;
                        html += `        <div class="pinl" style="display:none;" data-reply-box="true" data-id="` + item.TopicID + `">`;
                        html += `            <textarea placeholder="发布你的评论"></textarea>`;
                        if (item.ReplyContent == 0) {
                            html += `         <div class="plbtn" style="width:102px;height:28px">`;
                            html += `            <input type="button" class="sea_but1" data-id="` + item.TopicID + `" data-reply-submit="true" value="发布评论">`;
                            html += `         </div>`;
                        }
                        else {
                            html += `         <div class="plbtn">`;
                            html += `            <input type="button" class="sea_but1" data-id="` + item.TopicID + `" data-reply-submit="true" value="发布评论">`;
                            html += `             <a href="` + $("#url2").val() + item.TopicID + `.htm">查看评论</a>`
                            html += `         </div>`;
                        }
                        html += `         </div>`;
                        html += `        </div>`;
                        html += `    </div>`;
                        html += `</div>`;
                        html += `</div>`;
                    }
                    else {
                        html += `<div class="panew bottom">`;
                        html += `<div class="panel">`;
                        html += `    <div class="panelt">`;
                        html += `        <a class="ptimg" href="` + $("#url1").val() + item.TopicID + `.htm"><img src="` + (item.LogoUrl == "" ? "/Content/images/tox.png" : "https://img.chemicalbook.com/" + item.LogoUrl) + `"></a>`;
                        html += `    </div>`;
                        html += `    <div class="panelc sell_img">`;
                        html += `        <div class="ptname">`;
                        html += `            <div class="ptp">` + item.CompanyShortName + `<a class="pta" href="` + $("#url1").val() + item.TopicID + `.htm">@` + item.CompanyName + `</a></div>`;
                        html += `        </div>`;
                        if (item.MetaDecription == "") {
                            html += `        <div class="pctxt"></div>`;
                        }
                        else {
                            html += `        <div class="pctxt"><a href="` + $("#url2").val().replace("{topicid}", item.TopicID) + `">` + item.MetaDecription + `</a></div>`;
                        }
                        var shareImg = "";
                        if (item.Resources != null && item.Resources.length > 0) {
                            shareImg = item.Resources[0].ResourceUrl;
                            var imgClass = "spimg";
                            switch (item.Resources.length) {

                                case 1:
                                    imgClass = "spimg spimg1";
                                    break;
                                case 2:
                                    imgClass = "spimg spimg2";
                                    break;
                                case 3:
                                    imgClass = "spimg spimg3";
                                    break;
                                case 4:
                                    imgClass = "spimg spimg4";
                                    break;
                            }

                            html += `    <div class="` + imgClass + ` my-gallery"  data-pswp-uid="` + item.TopicID + `">`;
                            for (var j = 0; j < item.Resources.length; j++) {
                                html += `<figure>`;
                                html += ` <div class="sdiv` + (j + 1) + ` img-dv"><a href="` + item.Resources[j].ResourceUrl + `" data-size="500x400"></a><img data-img='true' data-size='0' src="` + item.Resources[j].ResourceUrl + `"></div>`;
                                html += `</figure>`;
                            }
                            html += ` </div>`;
                        }
                        html += `            <div class="updatetime">` + item.DateTimeDescribe + `</div>`;
                        html += ` </div>`;
                        html += ` <div class="panelb">`;
                        html += `        <span data-forward="true" data-id="` + item.TopicID + `" data-forwardcount="` + item.ForwardCount + `" data-share-title="` + item.MetaTitle + `" data-share-summary="` + item.MetaDecription + `" data-share-img="` + shareImg + `"><i class="zf"></i>` + item.ForwardCount + `</span>`;
                        html += `        <span data-reply="true" data-id="` + item.TopicID + `" data-replycount="` + item.ReplyCount + `"><i class="pl"></i>` + item.ReplyCount + `</span>`;
                        html += `        <span data-support="true" data-id="` + item.TopicID + `" data-supportcount="` + item.SupportCount + `"><i class="dz"></i>` + item.SupportCount + `</span>`;
                        html += `        <div class="pinl" style="display:none;" data-reply-box="true" data-id="` + item.TopicID + `">`;
                        html += `            <textarea placeholder="发布你的评论"></textarea>`;
                        if (item.ReplyContent == 0) {
                            html += `         <div class="plbtn" style="width:102px;height:28px">`;
                            html += `            <input type="button" class="sea_but1" data-id="` + item.TopicID + `" data-reply-submit="true" value="发布评论">`;
                            html += `         </div>`;
                        }
                        else {
                            html += `         <div class="plbtn">`;
                            html += `            <input type="button" class="sea_but1" data-id="` + item.TopicID + `" data-reply-submit="true" value="发布评论">`;
                            html += `             <a href="` + $("#url2").val() + item.TopicID + `.htm">查看评论</a>`
                            html += `         </div>`;
                        }

                        html += `       </div>`;
                        html += `   </div>`;
                        html += `</div>`;
                        html += `</div>`;
                    }

                    //upHighlight();
                }

                $("#plbox").append(html);
                $("span[data-forward='true']").unbind("click");
                $("span[data-reply='true']").unbind("click");
                $("span[data-support='true']").unbind("click");
                bindEvent();
            }
            else {
                lastPage = true;
            }
        }
    });
}

function bindEvent() {
    $("span[data-forward='true']").click(function () {
        var count = parseInt($(this).attr("data-forwardcount"));
        var id = $(this).attr("data-id");
        var summary = $(this).attr("data-share-summary");
        var shareImg = $(this).attr("data-share-img");
        var shareTitle = $(this).attr("data-share-title");
        var _this = this;
        $(this).addClass("xzl");
        tid = id;
        shareLink = window.location.origin + $("#url2").val() + id + ".htm";
        if ($("#host").val() == "M") {
            copyToClipboard(shareLink);
            alert("已复制链接!");
        }
        else if ($("#host").val() == "W") {
            shareSummary = summary;
            shareImgUrl = shareImg;
            shareTile = shareTitle;
            RegisterShare();
            $("div[data-share-modal='true']").show();
        }

        $.post("/BookCircle/Common/Forward", { operationid: tid }, function (result) {
            if (result > 0) {
                var span = $("span[data-forward='true'][data-id='" + tid + "']")
                var count = parseInt($(span).attr("data-forwardcount"));
                count = count + 1;
                var html = '<i class="zf"></i>' + count;
                $(span).html(html);
                $(span).attr("data-forwardcount", count);
                $(span).addClass("xzl");
            }
        });
    });

    $("span[data-reply='true']").click(function () {
        var count = parseInt($(this).attr("data-replycount"));
        var _thisp = this;
        $(this).addClass("xzl");
        var id = $(this).attr("data-id");
        if (getCookie("userName") == null) {
            $("#logo_go").click();

        }
        else {
            if ($("div[data-reply-box='true'][data-id='" + id + "']").css("display") == "none") {
                $("div[data-reply-box='true'][data-id='" + id + "']").show();
                $("input[data-reply-submit='true'][data-id='" + id + "']").click(function () {
                    var _this = this;
                    var content = $(this).prev().val();
                    if (content.trim().length == 0) {
                        alert("请输入评论内容!");
                        return;
                    }
                    var json = {};
                    json.TopicId = id;
                    json.ReplyContent = content;
                    $.post("/BookCircle/Common/SubmitReply", { replyJson: JSON.stringify(json) }, function (result) {
                        if (result > 0) {
                            alert("回复成功!");
                            $(_this).prev().val("");
                            $(_this).parent().hide();
                            $(_this).unbind("click");
                            count = count + 1;
                            var html = '<i class="pl"></i>' + count;
                            $(_thisp).html(html);
                            $(_thisp).attr("data-replycount", count);
                            $(_thisp).addClass("xzl");
                        }
                    });
                });
            }
            else {
                $("div[data-reply-box='true'][data-id='" + id + "']").hide();
            }
        }
    });

    $("span[data-support='true']").click(function () {
        if (getCookie("userName") == null) {
            $("#logo_go").click();
            return;
        }
        var _this = $(this);
        var id = $(this).attr("data-id");
        var count = parseInt($(this).attr("data-supportcount"));

        var _uuid = localStorage.getItem("_uuid");
        if (_uuid == null) {
            _uuid = uuid();
            localStorage.setItem("_uuid", _uuid);
        }

        $.post("/BookCircle/Common/UpTopic", { operationid: id, uuid: _uuid }, function (result) {
            if (result == 1) {
                count = count + 1;
                var html = '<i class="dz"></i>' + count;
                $(_this).html(html);
                $(_this).attr("data-supportcount", count);
                $(_this).addClass("xzl");
                var up = {};
                upArr = storageGet(up_session);
                if (upArr == null) {
                    upArr = [];
                }
                up.key = id;
                upArr.push(up);
                storageSet(up_session, upArr);
            }
            else if (result == 2) {
                count = count - 1;
                $(_this).attr("data-supportcount", count);
                var html = '<i class="dz"></i>' + count;
                $(_this).html(html);
                $(_this).removeClass("xzl");
                var up_data = storageGet(up_session);
                if (up_data) {
                    var index = -1;
                    for (var i = 0; i < up_data.length; i++) {
                        if (up_data[i].key == id) {
                            index = i;
                        }
                    }
                    if (index > -1) {
                        up_data.splice(index, 1);
                        storageSet(up_session, up_data);
                    }
                }
            }
        });
    });

    //var imgBox = document.querySelectorAll(".sell_img img");
    //for (var i = 0; i < imgBox.length; i++) {
    //    $(imgBox[i]).unbind("click");
    //    imgBox[i].onclick = function (e) {
    //        wxScale.start(this);
    //    }
    //}
    //var videos = $("div[data-type='video']");
    //for (var i = 0; i < videos.length; i++) {
    //    var id = $(videos[i]).attr("data-id");
    //    var mp = new MuiPlayer({
    //        container: "#video" + id,
    //        height: 225,
    //        autoFit: false,
    //        src: $(videos[i]).attr("data-src"),
    //        preload: "auto",
    //        autoplay: true
    //    })
    //}
    var videos = $("video");
    for (var i = 0; i < videos.length; i++) {
        //$("video")[i].play();
        //$("video")[i].pause();
    }

    var initPhotoSwipeFromDOM = function (gallerySelector) {
        // 解析来自DOM元素幻灯片数据（URL，标题，大小...）
        var parseThumbnailElements = function (el) {
            var thumbElements = el.childNodes,
                numNodes = thumbElements.length,
                items = [],
                figureEl,
                linkEl,
                size,
                item,
                divEl;
            for (var i = 0; i < numNodes; i++) {
                figureEl = thumbElements[i]; // <figure> element
                // 仅包括元素节点
                if (figureEl.nodeType !== 1) {
                    continue;
                }
                divEl = figureEl.children[0];
                linkEl = divEl.children[0]; // <a> element
                size = linkEl.getAttribute('data-size').split('x');
                // 创建幻灯片对象
                item = {
                    src: linkEl.getAttribute('href'),
                    w: parseInt(size[0], 10),
                    h: parseInt(size[1], 10)
                };
                if (figureEl.children.length > 1) {
                    item.title = figureEl.children[1].innerHTML;
                }
                if (linkEl.children.length > 0) {
                    // <img> 缩略图节点, 检索缩略图网址
                    item.msrc = linkEl.children[0].getAttribute('src');
                }
                item.el = figureEl; // 保存链接元素 for getThumbBoundsFn
                items.push(item);
            }
            return items;
        };

        // 查找最近的父节点
        var closest = function closest(el, fn) {
            return el && (fn(el) ? el : closest(el.parentNode, fn));
        };

        // 当用户点击缩略图触发
        var onThumbnailsClick = function (e) {
            e = e || window.event;
            e.preventDefault ? e.preventDefault() : e.returnValue = false;
            var eTarget = e.target || e.srcElement;
            var clickedListItem = closest(eTarget, function (el) {
                return (el.tagName && el.tagName.toUpperCase() === 'FIGURE');
            });
            if (!clickedListItem) {
                return;
            }
            var clickedGallery = clickedListItem.parentNode,
                childNodes = clickedListItem.parentNode.childNodes,
                numChildNodes = childNodes.length,
                nodeIndex = 1,
                index;
            for (var i = 0; i < numChildNodes; i++) {
                if (childNodes[i].nodeType !== 1) {
                    continue;
                }
                if (childNodes[i] === clickedListItem) {
                    index = nodeIndex;
                    break;
                }
                nodeIndex++;
            }
            if (index >= 0) {
                openPhotoSwipe(index, clickedGallery, true, true);
            }
            return false;
        };

        var photoswipeParseHash = function () {
            var hash = window.location.hash.substring(1),
                params = {};
            if (hash.length < 5) {
                return params;
            }
            var vars = hash.split('&');
            for (var i = 0; i < vars.length; i++) {
                if (!vars[i]) {
                    continue;
                }
                var pair = vars[i].split('=');
                if (pair.length < 2) {
                    continue;
                }
                params[pair[0]] = pair[1];
            }
            if (params.gid) {
                params.gid = parseInt(params.gid, 10);
            }
            return params;
        };

        var openPhotoSwipe = function (index, galleryElement, disableAnimation, fromURL) {
            var pswpElement = document.querySelectorAll('.pswp')[0],
                gallery,
                options,
                items;
            items = parseThumbnailElements(galleryElement);
            // 这里可以定义参数
            options = {
                barsSize: {
                    top: 100,
                    bottom: 100
                },
                fullscreenEl: false,
                shareButtons: [

                ],
                galleryUID: galleryElement.getAttribute('data-pswp-uid'),
                //getThumbBoundsFn: function (index) {
                //    var thumbnail = items[index].el.getElementsByTagName('img')[0], // find thumbnail
                //        pageYScroll = window.pageYOffset || document.documentElement.scrollTop,
                //        rect = thumbnail.getBoundingClientRect();
                //    return { x: rect.left, y: rect.top + pageYScroll, w: rect.width };
                //},
                tapToClose: true
            };
            if (fromURL) {
                if (options.galleryPIDs) {
                    for (var j = 0; j < items.length; j++) {
                        if (items[j].pid == index) {
                            options.index = j;
                            break;
                        }
                    }
                } else {
                    options.index = parseInt(index, 10) - 1;
                }
            } else {
                options.index = parseInt(index, 10);
            }
            if (isNaN(options.index)) {
                return;
            }
            if (disableAnimation) {
                options.showAnimationDuration = 0;
            }
            gallery = new PhotoSwipe(pswpElement, PhotoSwipeUI_Default, items, options);
            gallery.init();
        };

        var galleryElements = document.querySelectorAll(gallerySelector);
        for (var i = 0, l = galleryElements.length; i < l; i++) {
            galleryElements[i].setAttribute('data-pswp-uid', i + 1);
            galleryElements[i].onclick = onThumbnailsClick;
        }
        var hashData = photoswipeParseHash();
        if (hashData.pid && hashData.gid) {
            openPhotoSwipe(hashData.pid, galleryElements[hashData.gid - 1], true, true);
        }
    };

    initPhotoSwipeFromDOM('.my-gallery');

    var imgs = $("img[data-img='true'][data-size='0']");

    $(imgs).each(function () {
        var _this = this;
        $("<img />").attr("src", this.src).on("load", function () {
            var w = this.width;
            var h = this.height;
            $(_this).attr("data-size", 1);
            $(_this).prev().attr("data-size", w + "x" + h);
        });
    });
}

