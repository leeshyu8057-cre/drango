﻿function getScrollTop() {
    var scrollTop = 0;
    if (document.documentElement && document.documentElement.scrollTop) {
        scrollTop = document.documentElement.scrollTop;
    }
    else if (document.body) {
        scrollTop = document.body.scrollTop;
    }
    return Math.ceil(scrollTop);
}

function getScrollBarHeight() {
    let scrollBarHeight = document.documentElement.clientHeight;
    return Math.ceil(scrollBarHeight);
}

function getPageHeight() {
    return Math.ceil(Math.max(document.body.clientHeight, document.documentElement.scrollHeight));
}