﻿var isLoad = false;
var lastPage = false;
$(function () {
    bindEvent();

    url = "/BookCircle/Common/GetList"
    window.onscroll = function () {
        let top = getScrollTop();
        let ch = getScrollBarHeight();
        let sh = getPageHeight();
        if (top + ch >= sh - 200) {
            if (page >= 10 || isLoad) {
                return;
            }
            page++;
            loadTopic();
        } else {

        }
    }

    $("a[data-menu='true']").click(function () {
        var tag = $(this).attr("data-tag");
        if (tag=="zh") {
            location.href = "/bookcircle/index.htm";
        }
        else {
            location.href = "/bookcircle/" + tag+".htm";
        }
    });

    $("#search").click(function () {
        var kwd = $("#keyword").val();
        if (kwd.trim().length==0) {
            return;
        }
        lastPage = false;
        $("#list").find("div[class='panel']").remove();
        page = 1;
        loadTopic();
    });

    $("a[data-menu='true']").removeClass("dqq");
    $("a[data-tag='" + $("#tag").val() + "']").addClass("dqq");

    var videos = $("div[data-type='video']");
    for (var i = 0; i < videos.length; i++) {
        var id = $(videos[i]).attr("data-id");
        var mp = new MuiPlayer({
            container: "#video" + id,
            height: 225,
            autoFit:false,
            src: $(videos[i]).attr("data-src"),
        })
    }
});

