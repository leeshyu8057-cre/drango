﻿
var shareTile = "book圈-chemicalbook";
var shareSummary = "book圈公司最新动态";
var shareLink = window.location.origin + "/bookcircle/index.htm";
var shareImgUrl = "";

//注册分享功能0
var RegisterShare = function () {
    WxShareUpdateAppMessageShareData();
    WxShareUpdateTimelineShareData();
    WxShareWeibo();
    WxHideRefreshMenu();
};

//发送给朋友,QQ
var WxShareUpdateAppMessageShareData = function () {
    wx.updateAppMessageShareData({
        title: shareTile, // 分享标题
        desc: shareSummary, // 分享描述
        link: shareLink, // 分享链接，该链接域名或路径必须与当前页面对应的公众号JS安全域名一致
        imgUrl: shareImgUrl, // 分享图标
        success: function () {
            if (tid > 0) {
                
            }
        }
    })
};
//分享到朋友圈,QQ空间
var WxShareUpdateTimelineShareData = function () {
    wx.updateTimelineShareData({
        title: shareTile, // 分享标题
        desc:shareSummary,//分享描述
        link: shareLink, // 分享链接，该链接域名或路径必须与当前页面对应的公众号JS安全域名一致
        imgUrl: shareImgUrl, // 分享图标
        success: function () {
            if (tid > 0) {
                
            }
        }
    })
};
//分享到微博
var WxShareWeibo = function () {
    wx.onMenuShareWeibo({
        title: shareTile,
        desc: shareSummary,
        link: shareLink,
        imgUrl: shareImgUrl,
        success: function () {
            if (tid > 0) {
               
            }
        }
    });
};
var WxHideRefreshMenu = function () {
    wx.hideMenuItems({
        menuList: ['menuItem:copyUrl', 'menuItem:openWithQQBrowser', 'menuItem:openWithSafari', 'menuItem:favorite'] // 要隐藏的菜单项，只能隐藏“传播类”和“保护类”按钮，所有menu项见附录3
    });
}
function shareSuccess() {
     
}
$(function () {
    wx.ready(function () {
        RegisterShare();
    });
})