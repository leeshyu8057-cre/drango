﻿var isload = false;
var cas = "";
var winH = $(window).height(); //页面可视区域高度 
var pageCount;

var loadNewData = function () {
    isload = true;
    var page = parseInt((window.page || $("#page").val())) + 1;
    if (page>=41) {
        return;
    }
    $.post("/Home/ImageProduct_Global",
        {
            language: "en-us",
            page: page
        },
        function (data) {
            if (data.code == 0 && data.dataObj != null) {
                data.dataObj = JSON.parse(data.dataObj);
                var totalcount = 0;
                var shtml = "";
                for (var i = 0; i < data.dataObj.model.Table.length; i++) {
                    var entity = data.dataObj.model.Table[i];
                    var array = data.dataObj.model.Table1;

                    var drs = array.filter(item => item.ChemBookProductOfSuppliersID == entity.ID)

                    shtml += '<li class="cp_L" >';
                    shtml += '<a href="/ProductDetail_EN_' + entity.FormatUrl.toString().toLowerCase() + '.htm" target="_blank">';
                    shtml += '<p class="cp_BG"><img src="https://img.chemicalbook.com' + (entity.ProductImgURL.toString().replace("Raw", "Middle").replace("http://", "https://").replace("https://img.chemicalbook.com","")) + '"></p>';
                    shtml += '<p class="cp_1">' + entity.CAS + '</p>';
                    shtml += '<p class="cp_2">' + entity.ProdEName + ' </p>';
                    shtml += '<p class="cp_3">';
                    if (drs.length > 0) {
                        shtml += '<span>$' + drs[0]["SupplierListPrice"].toFixed(2) +'</span>';
                    }
                    shtml += '<span>' + entity.Purity + '</span>';
                    shtml += '</p>';
                    shtml += '</a>';
                    shtml += '</li>';




                    //shtml += '<div class="Box">';
                    //shtml += '    <div class="Quotation-t">';
                    //shtml += '        <p class="fl c3">No.:' + entity.InquiryListID + '</p>';
                    //shtml += '        <p class="fr c3">' + entity.InquiryStartTime.replace("T", " ") + '</p>';
                    //shtml += '        </div>';
                    //shtml += '            <div class="radiusBox">';
                    //shtml += '                <div class="ProName">';
                    //shtml += '                    <h2>';
                    //if (entity.ProductNameEN != 'undefined' && entity.ProductNameEN != null && entity.ProductNameEN != null && entity.ProductNameEN != undefined) {
                    //    shtml += entity.ProductNameEN;
                    //}
                    //else {
                    //    shtml += entity.ProdEName;
                    //}
                    //shtml += '                    </h2>';
                    //shtml += '                    <div class="Font15"><span>' + entity.CAS + '</span>&nbsp;&nbsp;<span class="c1 FontW">' + entity.QuantityDemanded + '</span> </div>';
                    //shtml += '                    <div class="Font15"><span class="c3">Shipments to:</span> <span class="blue">' + entity.Address + '</span></div>';
                    //shtml += '                </div>';
                    //shtml += '                    <div class="market"><p>' + entity.InquiryDescription;
                    //shtml += '                    </p><a href="/PurchaseHelper/Sales/AddQuatationEn?InquiryListIDStr=' + entity.InquiryListID + '&Inquiryidentification=' + entity.Inquiryidentification + '" class="DE blue">Add quote</a></div></div></div>';

                }
                if (data.dataObj.model.Table.length > 0) {
                    $("#boxList").append(shtml);
                }
                $("#page").val(data.dataObj.pager.Page);
                window.page = data.dataObj.pager.Page;
                pageCount = 3;//data.dataObj.pager.Pages;
                $("#PageCount").val(data.dataObj.pager.Pages);
                //if (pageCount == 0) {
                //    shtml = "";
                //    shtml += '<div class="caveat">';
                //    shtml += '    <div>!</div>';
                //    shtml += '    <p>You have no related orders</p>';
                //    shtml += '</div>';
                //    $("#boxList").append(shtml);
                //}
            } else {
                isload = false;
            }
            isload = false;
        }, "json").error(function () { isload = false; });
}

$(function () {
    pageCount = document.getElementById("PageCount").value;
    window.page = document.getElementById("page").value;
    $(window).scroll(function () {
        var pageH = $(document.body).height();
        var scrollT = $(window).scrollTop(); //滚动条top 
        var aa = (pageH - winH - scrollT) / winH;
        if (aa < 0.02) {
            if (window.page >= pageCount || isload) {
                return;
            }
            loadNewData();
        }
    });



});
