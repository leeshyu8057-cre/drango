﻿$(function () {
    $(".Client_bg").css("position", "initial");
    $(".Client_bg").addClass("Client_bg_1");
    $(".Client_bg").removeClass("Client_bg"); 
    $("#next").click(function () {
        if ($.trim($("#username").val()) == "") {
            $("#error").html('<i class="mark"></i>The username is not empty!');
            return;
        }

        if ($.trim($("#vercode").val()) == "") {
            $("#error").html('<i class="mark"></i>The verifying code is not empty!');
            return;
        }
        $.get("/Account/TestVerificationCode", { verificationCode: $("#vercode").val() }, function (result) {
            if (result) {
                $.get("/Account/TestEmail", { username: $("#username").val() }, function (result) {
                    if (!result) {
                        $(".Client_bg_1").addClass("Client_bg");
                        $(".Client_bg").css("position", "fixed");
                        $(".Client_w").show();
                        $("#part2").show();
                        $.post("/Account/GetUserEmail", { username: $("#username").val() }, function (result) {
                            if (result != "") {
                                $("#message1").text('Please click "OK", You will receive an email in your registed mail box : ' + result + ' .You can click on the link in the message to reset your password and security issues! ');

                                $("#message2").text('We have sent a email to your mail box:' + result + '.You can click on the link in the message to reset your password and security issues.');
                            }
                        });
                    }
                    else {
                        $("#error").html('<i class="mark">!</i>This user name has not been registered, please visit the registration page to register!');
                    }
                }, "json");
            }
            else{
                $("#error").html('<i class="mark"></i>Verification code error!');
            }
        }, "json"); 
    });
    $("#sendemail").click(function () {
        $.post("/Account/SendResetPasswordEmail", { UserName: $("#username").val() }, function (result) {
            if (result) {
                $("#part2").hide();
                $("#part3").show();
            }
            else {

            }
        }, "json");
    });

    $("#cancel").click(function () {
        $("#username").val("");
        $("#vercode").val(""); 
        $("#part2").hide();

        $(".Client_bg").css("position", "initial");
        $(".Client_bg").addClass("Client_bg_1");
        $(".Client_bg").removeClass("Client_bg"); 
    });

    $("#complete").click(function () {
        location.href = "/UserManager/Login_en.aspx";
    });
})