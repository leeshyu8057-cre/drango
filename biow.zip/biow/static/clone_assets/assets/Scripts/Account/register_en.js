﻿var registerType = 0;
var msg = "";
var register = {
    init: function ($sender, $err, userName, password, confirm, mobile) {
        this.$sender = $sender;
        this.$err = $err;
        this.userName = userName;
        this.password = password;
        this.confirm = confirm;
        this.mobile = mobile;
    },
    message: [],
    valide: function () {
        this.message.length = 0;
        if (!this.userName) {
            this.message.push("E-mail can not be empty");
        }
        else {
            if (this.userName.length > 80) {
                this.message.push("The mailbox length cannot exceed 80");
            } else {
                var emailReg = /^[a-zA-Z0-9.!#$%&'*+\/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
                if (!emailReg.test(this.userName)) {
                    this.message.push("E-mail format is incorrect");
                }
            }
        }
        var msg = detectionPasswordMsg();
        if (msg && msg.length > 0) {
            this.message = this.message.concat(msg);
        }

        if (this.password != this.confirm) {
            this.message.push("The passwords are inconsistent twice, please re-enter");
        }

        if (!this.mobile) {
            this.message.push("Phone number cannot be empty");
        } else {
            //var mobileReg = /^1[3|4|5|7|8|9][0-9]\d{4,8}$/;
            var mobileReg = /^\d{8,20}$/;
            if (!mobileReg.test(this.mobile)) {
                this.message.push("please enter the correct phone number");
            }
        }
        var agree = $("#chk_agree");
        if (agree && agree.length > 0) {
            if (!agree.prop("checked")) {
                this.message.push("You agree to register for an account on chemicalbook");
            }
        }

        if (this.message.length > 0) {
            this.showMsg()
            return false;
        }

        return true;
    },

    showMsg: function (msg) {
        if (msg) {
            this.$err.html(msg).show();
            return;
        }
        if (this.message.length > 0) {
            this.$err.html(this.message.join("<br />")).show();
        }
    },
    regist: function () {
        this.$sender.prop("disabled", true);
        var $this = this;
        $("#register").val('Registering...');
        $.ajax({
            url: "/account/registerEn",
            type: "POST",
            data: { userName: this.userName, password: this.password, confirm: this.confirm, mobile: this.mobile, type: registerType },
            dataType: "json",
            success: function (json) {
                if (json.code == 0) {
                    var retunurl = $("#returnurl").val();
                    retunurl = decodeURIComponent(retunurl);
                    if (retunurl != undefined && retunurl != '') {
                        if (retunurl.indexOf("AddInquiryEn") >= 0) {
                            var reg = new RegExp("(^|&)datastr=([^&]*)(&|$)", "i");
                            var r = retunurl.match(reg);
                            if (r != null) {
                                var cookieName = r[2];
                                if (cookieName != undefined && cookieName != '') {
                                    var strCookieVal = getCookie(cookieName);
                                    if (strCookieVal != null && strCookieVal != undefined) {
                                        var strDataObj = JSON.parse(strCookieVal);
                                        var argument = {
                                            cbsid: strDataObj.cbsid,
                                            productname: strDataObj.productname,
                                            cas: strDataObj.cas,
                                            cbnumber: strDataObj.cbnumber,
                                            number: strDataObj.amount + strDataObj.unitname,
                                            unit: strDataObj.unit,
                                            port: 1,
                                            portdescribe: "",
                                            country: strDataObj.country,
                                            describtion: strDataObj.describtion,
                                            attachmentpath: "",
                                            inquirysource: strDataObj.inquirysource,
                                            countrytext: strDataObj.countrytext,
                                            amount: strDataObj.amount
                                        };
                                        if (strDataObj.cbsid != '' && strDataObj.cbsid != undefined) {
                                            inquirySave(argument, 'GlobalDelegateInquiryToSupplier');
                                        }
                                        else {
                                            inquirySave(argument, 'GlobalDelegateInquiry');
                                        }
                                    }
                                }
                            }
                            if (retunurl != undefined && retunurl != '' && retunurl.split('&').length > 0) {
                                var returnUrlStr = "";
                                for (var i = 0; i < retunurl.split('&').length; i++) {
                                    if (retunurl.split('&')[i].indexOf("msg") < 0) {
                                        returnUrlStr += retunurl.split('&')[i] + "&";
                                    }
                                }
                                window.location.href = returnUrlStr.substr(0, returnUrlStr.length - 1) + "&msg=" + msg;
                            }
                            else {
                                window.location.href = "/ProductIndex_EN.aspx";
                            }
                        }
                        else {
                            window.location.href = retunurl;
                        }
                    } else {
                        window.location.href = "/ProductIndex_EN.aspx";
                    }
                }
                else {
                    $this.showMsg(json.msg);
                }
            },
            complete: function () {
                $this.$sender.prop("disabled", false);
            }
        })
    }
}
function inquirySave(argument, inquiryUrl) {
    $.ajax({
        url: "/PurchaseHelper/Purchase/" + inquiryUrl,
        cache: false,
        type: "Post",
        async: false,
        data: { str: JSON.stringify(argument) },
        dataType: "text",
        success: function (data) {
            var dataobj = $.parseJSON(data);
            msg = dataobj.msg;
        }
    })
}
function getCookie(name) {
    var arr, reg = new RegExp("(^| )" + name + "=([^;]*)(;|$)");
    if (arr = document.cookie.match(reg))
        return unescape(arr[2]);
    else
        return null;
}
$(function () {
    $("#register").click(function () {
        var userName = $("#userName").val().trim();
        var mobile = $("#mobile").val().trim();
        var email = userName;
        var phone = mobile;
        if (registerType == 1) {
            email = mobile;
            phone = userName;
        }

        var password = $("#password").val().trim();
        var confirm = $("#confirm").val().trim();

        var $sender = $(this);
        var $err = $("#err");

        $("#userName").val(userName);
        $("#password").val(password);
        $("#confirm").val(confirm);
        $("#mobile").val(mobile);

        register.init($sender, $err, email, password, confirm, phone);
        if (!register.valide()) {
            return;
        }
        register.regist();
    });

    $("#switch").click(function () {
        if (registerType == 0) {
            $("#userName").attr("placeholder", "phone number");
            $("#mobile").attr("placeholder", "mailbox");
            $("#switch").text("Use email registration");
            registerType = 1;
        } else {
            $("#userName").attr("placeholder", "mailbox");
            $("#mobile").attr("placeholder", "phone number");
            $("#switch").text("Register with your mobile phone number");
            registerType = 0;
        }

    });
    $("#password").popover({
        container: "body",
        placement: "top",
        html: true,
        trigger: "focus",
        content: function () {
            return detectionPassword();//"请输入8-20位密码<br />大小写字母、数字、特殊字符至少包含三种";
        },
        title: function () {
            return "Your password:";
        }
    });
    $('#password').on('shown.bs.popover', function () {
        $(".popover .arrow")[0].style.left = "10%";
    })
    $("#password").keyup(function () {
        var html = detectionPassword();
        $(this).closest('body').find('.popover .popover-content').html(html);
    });
})


function detectionPassword() {
    var policy = $("#policy").val();
    var numberDesc = 2;
    var stringDesc = "two"
    if (policy == "3") {
        numberDesc = 3;
        stringDesc = "three";
    }
    var el = $("#password");
    var html = '';
    html += '<ul style="list-style:none;">';
    html += '<li class="len">Must be 8-20 characters characters in length</li>';
    html += '<li class="fh">Must contain ' + stringDesc + ' of the below:<br />- One uppercase character<br />- One lowercase character<br />- One special character<br />- One number</li>';
    html += '<li class="sp">Must be no space</li>';
    html += '</ul>';
    var $html = $(html);
    var len = false;
    var sp = false;
    var fh = true;
    var val = el.val();
    if (el.val() == "") {
        return $html[0];
    }
    else {
        var isPassword = /^.{8,20}$/
        if (!isPassword.test(val)) {
            $html.find(".len").html("× Must be 8-20 characters characters in length").css("color", "red");
            len = false;
        }
        else {
            len = true;
            $html.find(".len").html("✔ Must be 8-20 characters characters in length").css("color", "#000");
        }

        var dxx = /[a-z]/;
        var dxxcount = 0;
        if (dxx.test(val)) {
            dxxcount++;
        }
        var dxx = /[A-Z]/;
        if (dxx.test(val)) {
            dxxcount++;
        }
        var dxx = /[0-9]/;
        if (dxx.test(val)) {
            dxxcount++;
        }
        var dxx = /\W/;
        if (dxx.test(val)) {
            dxxcount++;
        }
        if (dxxcount >= numberDesc) {
            fh = true;
            $html.find(".fh").html("✔ Must contain " + stringDesc + " of the below:<br />- One uppercase character<br />- One lowercase character<br />- One special character<br />- One number").css("color", "#000");
        } else {
            fh = false;
            $html.find(".fh").html("× Must contain " + stringDesc + " of the below:<br />- One uppercase character<br />- One lowercase character<br />- One special character<br />- One number").css("color", "red");
        }

        var spzz = /[\s|\u4e00-\u9fa5]/;
        if (spzz.test(val)) {
            sp = false;
            $html.find(".sp").html("× Must be no space").css("color", "red");
        } else {
            sp = true;
            $html.find(".sp").html("✔ Must be no space").css("color", "#000");
        }
        if (len && fh && sp) {
            el.removeClass("error");
        } else {
            el.addClass("error");
        }
        return $html[0];
    }
}
function detectionPasswordMsg() {
    var policy = $("#policy").val();
    var numberDesc = 2;
    var stringDesc = "two"
    if (policy == "3") {
        numberDesc = 3;
        stringDesc = "three";
    }
    var el = $("#password");
    var len = false;
    var sp = false;
    var fh = true;
    var val = el.val();
    var msg = [];
    if (el.val() == "") {
        msg.push('Password cannot be empty');
    }
    else {
        var isPassword = /^.{8,20}$/
        if (!isPassword.test(val)) {
            msg.push('The password length is 8 ~ 20 characters');
        }

        var dxx = /[a-z]/;
        var dxxcount = 0;
        if (dxx.test(val)) {
            dxxcount++;
        }
        var dxx = /[A-Z]/;
        if (dxx.test(val)) {
            dxxcount++;
        }
        var dxx = /[0-9]/;
        if (dxx.test(val)) {
            dxxcount++;
        }
        var dxx = /\W/;
        if (dxx.test(val)) {
            dxxcount++;
        }
        if (dxxcount < numberDesc) {
            msg.push('The password should has at least ' + stringDesc + ' types out of the uppercase character, lowercase character, number and special character.');
        }

        var spzz = /[\s]/;
        if (spzz.test(val)) {
            msg.push('The password does not allow spaces');
        }
        var spzz = /[\u4e00-\u9fa5]/;
        if (spzz.test(val)) {
            msg.push('The password does not allow Chinese characters');
        }
    }
    return msg;
}