﻿
function GetIP() {
    var ip = "";

    $.ajax({

        url: "/Handler/GetIP.ashx",
        async: false,
        dataType: "json",
        success: function (data) {

            if (data.success == "true") {

                ip = data.ip;
            }
        }
    });
    return ip;
}

function AddLogAsync(value) {
    try {
        var tmepUrl = "https://mapi.chemicalbook.com/mapi/AddLog?value=" + escape(value);
        $.ajax({
            url: tmepUrl,
            type: "get",
            async: true,
            dataType: 'JSONP',
            jsonp: "callback",
            success: function (ret) {
            }
        })
    } catch (e) {
    }
}

function AddLog(value) {
    try {
        var tmepUrl = "https://mapi.chemicalbook.com/mapi/AddLog?value=" + escape(value);
        $.ajax({
            url: tmepUrl,
            type: "get",
            dataType: 'JSONP',
            jsonp: "callback",
            success: function (ret) {
            }
        })
    } catch (e) {
    }
}

function MGetCookie(name) {
    try {
        var arr, reg = new RegExp("(^| )" + name + "=([^;]*)(;|$)");
        if (arr = document.cookie.match(reg)) {
            return unescape(arr[2]);
        }
    } catch (e) {
    }
    return "";
}

function ModuleLog(LogType, module, PageUrl) {
    try {

        var meIP = GetIP();
        var data = {
            "IP": meIP,
            "LogType": LogType,
            "Module": module,
            "LoginUserName": MGetCookie("userName"),
            "PageUrl": PageUrl,
            "AllPath": window.location.href,
            "ParentUrl": window.parent.location.href
        };
        var value = JSON.stringify(data);
        AddLog(value);
    } catch (e) {
    }
}

function SearchLog(mid, PageUrl) {
    try {
        var meIP = GetIP();
        var data = {
            "IP": meIP,
            "LogType": "3",
            "Module": "查询",
            "SearchValue": $("#" + mid).val(),
            "LoginUserName": MGetCookie("userName"),
            "PageUrl": PageUrl,
            "AllPath": window.location.href,
            "ParentUrl": window.parent.location.href
        };
        var value = JSON.stringify(data);
        AddLogAsync(value);
    } catch (e) {
    }
}

document.onclick = function (e) {

    try {

        var e = e ? e : window.event;

        var tar = e.srcElement || e.target;

        var target = $(tar);

        if (GetAttribute(target, "data-module") != "") {

            var LogType = GetAttribute(target, "data-log-type");

            if (LogType == "") {

                LogType = "4";
            }
            //var meIP = GetIP();
            var data = {
                "IP": "",
                "LogType": LogType,
                "Module": GetAttribute(target, "data-module"),
                "LoginUserName": MGetCookie("userName"),
                "UserName": GetAttribute(target, "data-user-name"),
                "Brand": GetAttribute(target, "data-brand"),
                "PageUrl": GetAttribute(target, "data-page-url"),
                "AllPath": GetLogInfoUrl(window.location.href),
                "ParentUrl": GetLogInfoUrl(window.parent.location.href),
                "SearchValue": GetAttribute(target, "data-search-value"),
                "SearchCount": GetAttribute(target, "data-search-count"),
                "Cas": GetAttribute(target, "data-cas"),
                "CBNumber": GetAttribute(target, "data-cbnumber"),
                "Result": GetAttribute(target, "data-result"),
                "CBSID": GetAttribute(target, "data-cbsid"),
                "FilterCond": GetAttribute(target, "data-filter-cond"),
                "QQNumber": GetAttribute(target, "data-qq-number"),
                "KeyValue1": GetAttribute(target, "data-key-value1"),
                "KeyValue2": GetAttribute(target, "data-key-value2"),
                "KeyValue3": GetAttribute(target, "data-key-value3"),
                "TwoModule": GetAttribute(target, "data-two-module"),
                "ThreeModule": GetAttribute(target, "data-three-module"),
                "FourModule": GetAttribute(target, "data-four-module")
            };
            var value = JSON.stringify(data);

            AddLogAsync(value);
        }


    } catch (e) {

    }
}

function GetAttribute(target, attributeName) {

    var strReturn = target.attr(attributeName);

    if (typeof (strReturn) == "undefined") {

        return "";
    }

    return strReturn;

}

function GetLogInfoUrl(str) {

    try {

        var endIndex = 120;

        if (str.length < endIndex) {

            endIndex = str.length;
        }

        return str.substring(0, endIndex);

    } catch (e) {

        return "";
    }

}

function GetLogInfoSubString(str, endIndex) {

    try {

        if (str.length < endIndex) {

            endIndex = str.length;
        }

        return str.substring(0, endIndex);

    } catch (e) {

        return "";
    }

}

$(function () {
    $(".Downwards,.Deal,[data-mts='mouseenter']").mouseenter(function () {
        var LogType = "4";
        
        //var meIP = GetIP();
        var data = {
            "IP": "",
            "LogType": LogType,
            "Module": GetAttribute($(this), "data-module"),
            "LoginUserName": MGetCookie("userName"),
            "UserName": GetAttribute($(this), "data-user-name"),
            "Brand": GetAttribute($(this), "data-brand"),
            "PageUrl": GetAttribute($(this), "data-page-url"),
            "AllPath": GetLogInfoUrl(window.location.href),
            "ParentUrl": GetLogInfoUrl(window.parent.location.href),
            "SearchValue": GetAttribute($(this), "data-search-value"),
            "SearchCount": GetAttribute($(this), "data-search-count"),
            "Cas": GetAttribute($(this), "data-cas"),
            "CBNumber": GetAttribute($(this), "data-cbnumber"),
            "Result": GetAttribute($(this), "data-result"),
            "CBSID": GetAttribute($(this), "data-cbsid"),
            "FilterCond": GetAttribute($(this), "data-filter-cond"),
            "QQNumber": GetAttribute($(this), "data-qq-number"),
            "KeyValue1": GetAttribute($(this), "data-key-value1"),
            "KeyValue2": GetAttribute($(this), "data-key-value2"),
            "KeyValue3": GetAttribute($(this), "data-key-value3"),
            "TwoModule": GetAttribute($(this), "data-two-module"),
            "ThreeModule": GetAttribute($(this), "data-three-module"),
            "FourModule": GetAttribute($(this), "data-four-module")
        };
        var value = JSON.stringify(data);

        AddLogAsync(value);
    });
})




