﻿

/*!
 * ASP.NET SignalR JavaScript Library v2.2.2
 * http://signalr.net/
 *
 * Copyright (c) .NET Foundation. All rights reserved.
 * Licensed under the Apache License, Version 2.0. See License.txt in the project root for license information.
 *
 */

/// <reference path="..\..\SignalR.Client.JS\Scripts\jquery-1.6.4.js" />
/// <reference path="jquery.signalR.js" />
//(function ($, window, undefined) {
//    /// <param name="$" type="jQuery" />
//    "use strict";

//    if (typeof ($.signalR) !== "function") {
//        throw new Error("SignalR: SignalR is not loaded. Please ensure jquery.signalR-x.js is referenced before ~/signalr/js.");
//    }

//    var signalR = $.signalR;
//    function MyGetCookie(name) {
//        try {
//            var arr, reg = new RegExp("(^| )" + name + "=([^;]*)(;|$)");
//            if (arr = document.cookie.match(reg)) {
//                return unescape(arr[2]);
//            }
//        } catch (e) {
//        }
//        return "";
//    }
//    function makeProxyCallback(hub, callback) {
//        return function () {
//            // Call the client hub method
//            callback.apply(hub, $.makeArray(arguments));
//        };
//    }

//    function registerHubProxies(instance, shouldSubscribe) {
//        var key, hub, memberKey, memberValue, subscriptionMethod;

//        for (key in instance) {
//            if (instance.hasOwnProperty(key)) {
//                hub = instance[key];

//                if (!(hub.hubName)) {
//                    // Not a client hub
//                    continue;
//                }

//                if (shouldSubscribe) {
//                    // We want to subscribe to the hub events
//                    subscriptionMethod = hub.on;
//                } else {
//                    // We want to unsubscribe from the hub events
//                    subscriptionMethod = hub.off;
//                }

//                // Loop through all members on the hub and find client hub functions to subscribe/unsubscribe
//                for (memberKey in hub.client) {
//                    if (hub.client.hasOwnProperty(memberKey)) {
//                        memberValue = hub.client[memberKey];

//                        if (!$.isFunction(memberValue)) {
//                            // Not a client hub function
//                            continue;
//                        }

//                        subscriptionMethod.call(hub, memberKey, makeProxyCallback(hub, memberValue));
//                    }
//                }
//            }
//        }
//    }

//    $.hubConnection.prototype.createHubProxies = function () {
//        var proxies = {};
//        this.starting(function () {
//            // Register the hub proxies as subscribed
//            // (instance, shouldSubscribe)
//            registerHubProxies(proxies, true);

//            this._registerSubscribedHubs();
//        }).disconnected(function () {
//            // Unsubscribe all hub proxies when we "disconnect".  This is to ensure that we do not re-add functional call backs.
//            // (instance, shouldSubscribe)
//            registerHubProxies(proxies, false);
//            //this.start();
//        });


//        proxies['reagentOrderValidPriceHub'] = this.createHubProxy('reagentOrderValidPriceHub');
//        proxies['reagentOrderValidPriceHub'].client = {};
//        proxies['reagentOrderValidPriceHub'].server = {
//            getReagentPriceChangeInfo: function () {
//                return proxies['reagentOrderValidPriceHub'].invoke.apply(proxies['reagentOrderValidPriceHub'], $.merge(["GetReagentPriceChangeInfo"], $.makeArray(arguments)));
//            },
//            notifyConfirm: function (ids) {
//                return proxies['reagentOrderValidPriceHub'].invoke.apply(proxies['reagentOrderValidPriceHub'], $.merge(["NotifyConfirm"], $.makeArray(arguments)));
//            },
//            validReagentPriceRequest: function (IdOfInquiry) {
//                return proxies['reagentOrderValidPriceHub'].invoke.apply(proxies['reagentOrderValidPriceHub'], $.merge(["ValidReagentPriceRequest"], $.makeArray(arguments)));
//            },
//        };

//        proxies['testHub'] = this.createHubProxy('testHub');
//        proxies['testHub'].client = {};
//        proxies['testHub'].server = {
//            send: function (name, msg) {
//                return proxies['testHub'].invoke.apply(proxies['testHub'], $.merge(["Send"], $.makeArray(arguments)));
//            }
//        };

//        return proxies;
//    };
//    var src = $("[src*='/Scripts/signalr/hubs.js']").attr("src");
//    var host = src.substring(0, src.indexOf("/Scripts/signalr/hubs.js"));
//    signalR.hub = $.hubConnection(host + "/signalr", { useDefaultPath: false });
//    signalR.hub.qs = {
//        "_userName": MyGetCookie("_userName"),
//        "_UserToken": MyGetCookie("_userName"),
//        "userName": MyGetCookie("userName"),
//        "UserToken": MyGetCookie("UserToken"),
//        "userValid": MyGetCookie("userValid")
//    };
//    $.extend(signalR, signalR.hub.createHubProxies());

//}(window.jQuery, window));

if (!getCookie) {
    function getCookie(name) {
        try {
            var arr, reg = new RegExp("(^| )" + name + "=([^;]*)(;|$)");
            if (arr = document.cookie.match(reg)) {
                return unescape(arr[2]);
            }
        } catch (e) {
        }
        return "";
    }
}

var src = $("[src*='/signalr/hubs']").attr("src");
var host = src.substring(0, src.indexOf("/signalr/hubs"));
$.connection.hub.url = host + "/signalr";
$.connection.hub.qs = {
    "__ancsi_": getCookie("__ancsi_"),
    "__ancsi_t_": getCookie("__ancsi_t_"),
    "_ancsi_": getCookie("_ancsi_"),
    "_ancsi_t_": getCookie("_ancsi_t_"),
    "_userName": getCookie("_userName"),
    "_UserToken": getCookie("_UserToken"),
    "userName": getCookie("userName"),
    "UserToken": getCookie("UserToken"),
    "userValid": getCookie("userValid")
};