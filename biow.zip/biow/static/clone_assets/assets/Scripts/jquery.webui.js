﻿(function ($) {
    var enumTipType = { success: "success", loading: "loading", waring: "warning", error: "error", info: "info" };

    $.WebUI = {};
    //弹出提醒,c：提示内容，t:提示类型(success,warning,loading) times:自动消失时长 毫秒
    $.WebUI.toast = function (c, t, times) {
        if (t != "success" && t != "loading" && t != "warning" && t != "error" && t != "info") {
            return;
        }
        var h = ""; var s = "#toast";
        switch (t) {
            case enumTipType.success:
                h += "<div id='toast'>";
                h += "    <div class='weui_mask_transparent'></div>";
                h += "    <div class='weui_toast'>";
                h += "        <i class='weui_icon_toast'></i>";
                h += "        <p class='weui_toast_content'>" + c + "</p>";
                h += "    </div>";
                h += "</div>";
                break;
            case enumTipType.error:
                h += "<div id='toast'>";
                h += "    <div class='weui_mask_transparent'></div>";
                h += "    <div class='weui_toast'>";
                h += "        <i class='weui_icon_toast weui_icon_clear'></i>";
                h += "        <p class='weui_toast_content'>" + c + "</p>";
                h += "    </div>";
                h += "</div>";
                break;
            case enumTipType.waring:
                h += "<div id='toast'>";
                h += "    <div class='weui_mask_transparent'></div>";
                h += "    <div class='weui_toast'>";
                h += "        <i class='weui_icon_toast weui_icon_warn'></i>";
                h += "        <p class='weui_toast_content'>" + c + "</p>";
                h += "    </div>";
                h += "</div>";
                break;
            case enumTipType.info:
                h += "<div id='toast'>";
                h += "    <div class='weui_mask_transparent'></div>";
                h += "    <div class='weui_toast'>";
                h += "        <i class='weui_icon_toast weui_icon_info'></i>";
                h += "        <p class='weui_toast_content'>" + c + "</p>";
                h += "    </div>";
                h += "</div>";
                break;
            case enumTipType.loading:
                h += "<div id='toast' class='weui_loading_toast'>";
                h += "    <div class='weui_mask_transparent'></div>";
                h += "    <div class='weui_toast'>";
                h += "        <div class='weui_loading'>";
                h += "            <!-- :) -->";
                h += "            <div class='weui_loading_leaf weui_loading_leaf_0'></div>";
                h += "            <div class='weui_loading_leaf weui_loading_leaf_1'></div>";
                h += "            <div class='weui_loading_leaf weui_loading_leaf_2'></div>";
                h += "            <div class='weui_loading_leaf weui_loading_leaf_3'></div>";
                h += "            <div class='weui_loading_leaf weui_loading_leaf_4'></div>";
                h += "            <div class='weui_loading_leaf weui_loading_leaf_5'></div>";
                h += "            <div class='weui_loading_leaf weui_loading_leaf_6'></div>";
                h += "            <div class='weui_loading_leaf weui_loading_leaf_7'></div>";
                h += "            <div class='weui_loading_leaf weui_loading_leaf_8'></div>";
                h += "            <div class='weui_loading_leaf weui_loading_leaf_9'></div>";
                h += "            <div class='weui_loading_leaf weui_loading_leaf_10'></div>";
                h += "            <div class='weui_loading_leaf weui_loading_leaf_11'></div>";
                h += "        </div>";
                h += "        <p class='weui_toast_content'>" + c + "</p>";
                h += "    </div>";
                h += "</div>";
                break;
            default: break;
        }
        if ($("body").find("#toast").length > 0) {
            $("#toast").remove();
        }
        $("body").append(h);
        if (t != enumTipType.loading) {
            autohide(s, times || 1500);
        }
    }
    //关闭弹出的提醒
    $.WebUI.closetoast = function () {
        $("#toast").remove();
    }

    //弹出窗口
    $.WebUI.dialog = function (options) {
        var settings = { title: "", content: "", buttons: [] };
        jQuery.extend(settings, options);

        var $weui_dialog_confirm = $("<div class='weui_dialog_confirm'></div>");
        var $weui_mask = $("<div class='weui_mask'></div>");
        var $weui_dialog = $("<div class='weui_dialog'></div>");

        var $weui_dialog_hd = $("<div class='weui_dialog_hd'><strong class='weui_dialog_title'>" + settings.title + "</strong></div>");
        var $weui_dialog_bd = $("<div class='weui_dialog_bd'>" + settings.content + "</div>");

        $weui_dialog.append($weui_dialog_hd);
        $weui_dialog.append($weui_dialog_bd);


        $weui_dialog_confirm.append($weui_mask);
        $weui_dialog_confirm.append($weui_dialog);

        var arrButtons = settings.buttons;
        if (settings.buttons.length > 0) {
            var $btnnar = $("<div class='weui_dialog_ft'></div>");
            for (var i = 0; i < arrButtons.length; i++) {
                var $obj_a = $("<a href='javascript:void(0);' class='weui_btn_dialog'></a>");
                if (arrButtons[i].text == "" || arrButtons[i].text == undefined || arrButtons[i].text == null) {
                    $obj_a.html("Button");
                } else {
                    $obj_a.html(arrButtons[i].text);
                }

                if (arrButtons[i].clsname == "" || arrButtons[i].clsname == undefined || arrButtons[i].clsname == null) {
                    $obj_a.addClass("default");
                } else {
                    $obj_a.addClass(arrButtons[i].clsname);
                }
                if (arrButtons[i].handler != "" && arrButtons[i].handler != undefined || arrButtons[i].handler != null) {
                    $obj_a[0].onclick = arrButtons[i].handler;
                }
                $btnnar.append($obj_a);
            }

            $weui_dialog.append($btnnar);

        }
        $("body").append($weui_dialog_confirm);
    }
    $.WebUI.closedialog = function () {
        $(".weui_dialog_confirm").remove();
    }


    //自动隐藏
    function autohide(s, times) {
        setTimeout(function () {
            $(s).remove();
        }, times);
    }
})(jQuery);