﻿
var isload = false;
var pageCount;
var winH = $(window).height(); //页面可视区域高度 
$(function () {
    pageCount = $("#PageCount").val() || 0;
    window.page = $("#page").val();
    $(window).scroll(function () {
        var pageH = $(document.body).height();
        var scrollT = $(window).scrollTop(); //滚动条top 
        var aa = (pageH - winH - scrollT) / winH;
        if (aa < 0.5) {
            if (window.page >= pageCount || isload) {
                if (window.page >= pageCount) {
                    //$("#baseline").show();
                }
                return;
            }
            loadNewData(true);
        }
    });
})
var loadNewData = function (isScroll) {
    //if (!isScroll) {
    //    $("#baseline").hide();
    //}
    isload = true;
    var page = parseInt((window.page || $("#page").val())) + 1;
    $.post("/Home/GetLatestProductFreeData",
        {
            page: page
        },
        function (data) {
            if (data) {
                var totalcount = 0;
                var shtml = "";
                if (data.length > 0) {
                    for (var i = 0; i < data.length; i++) {
                        var price = 0;
                        price = parseFloat(data[i].PriceDescription);
                        shtml += '<div class="gylist">';
                        shtml += '<a class="xximg" href="/SupplyInfo_' + data[i].Id + '.htm"><img src="' + (data[i].ChemicalImgUrl == "" ? "https://img.chemicalbook.com/applet/images/noimg.gif" : "https://img.chemicalbook.com/" + data[i].ChemicalImgUrl) + '"></a>';
                        shtml += '<a class="xxname" href="/SupplyInfo_' + data[i].Id + '.htm">' + data[i].DescriptionC + '</a>';
                        shtml += '<div class="xxgs">';
                        shtml += '<div>' + data[i].Publisher.Name + '</div>';
                        if (data[i].Publisher.ISVIP == 1) {
                            shtml += '<span>VIP</span>';
                        }
                        shtml += '</div>';
                        shtml += '<div class="xxjg">';
                        shtml += '<span class="xxjgs1">';
                        if (price > 10) {
                            shtml += '("￥" + ' + data[i].PriceDescription + ')';
                        }
                        else {
                            shtml += "询价";
                        }
                          
                        shtml += '</span>';
                        shtml += '<span class="xxjgs2">' + convertDate(data[i].PublishedDate) + '</span>';
                        shtml += '</div>';
                        shtml += '</div>';
                    }
                }
                if (shtml) {
                    $(".gyxxbox").append(shtml);
                }
                $("#page").val(page);
                window.page = page;
            } else {
                isload = false;
            }
            isload = false;
        }, "json").error(function () { isload = false; });
}
function convertDate2(input) {
    if (input) {
        // 去除前后的括号，并转换为数字
        var timestamp = parseInt(input.replace(/\/Date\((-?\d+)\)\//, '$1'), 10);
        // 新建一个Date对象
        return new Date(timestamp);
    }
    return input;
}
function convertDate(input) {
    // 将输入字符串转换为 JavaScript Date 对象
    var date = new Date(parseInt(input.substr(6)));

    // 使用 JavaScript 的 Date 方法获取年月日
    var year = date.getFullYear();
    var month = date.getMonth() + 1; // 月份是从0开始的
    var day = date.getDate();

    // 补零操作确保月份和日期始终是两位数
    month = (month < 10 ? '0' : '') + month;
    day = (day < 10 ? '0' : '') + day;

    // 返回格式化的年月日字符串
    return year + '-' + month + '-' + day;
}
