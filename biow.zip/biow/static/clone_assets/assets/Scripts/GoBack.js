﻿/*返回*/
$(function () {
    $("#goBack").click(function () {
        var goto = $(this).attr("goto");
        if (goto) {
            if (goto == "/") {
                var c = new cookieoper();
                c.clearCookie();
            }
            location.href = goto;
            return false;
        }
        var url = window.location.href;
        var reurl = document.referrer;
        var host = document.host;
        if (reurl && reurl.indexOf(host) != -1) {
            window.location.href = document.referrer;
        } else {
            window.history.back();
        }
        return;
    });

});
