﻿
$(function () {
    var t = $(window).scrollTop();
    var isload = false;
    ///通用   tab菜单向下滑隐藏,向上显示
    $(window).scroll(function () {
        var pageH = $(document.body).height();
        var scrollT = $(window).scrollTop(); //滚动条top
        if (scrollT > 60) {
            if (!isload) {
                isload = true;
                if (scrollT - t > 0) {
                    $(".tabMenu").animate({ "opacity": 0 }, 400, "", function () {
                        isload = false;
                    });
                } else {
                    $(".tabMenu").animate({ "opacity": 1 }, 400, "", function () {
                        isload = false;
                    });
                }

            }
        }
        t = scrollT;
    });
});
//Customized form attribute judgment
jQuery.extend({
    //Judge whether it is a phone call, if it returns true, if not, it returns false
    isTelephone: function (a) {//Verify phone (including mobile phone and landline)
        var isPhone = /^([0-9]{3,4}-)?[0-9]{7,8}$/;
        var isMob = /^1\d{10}$/;
        if (isMob.test(a) || isPhone.test(a)) {
            return true;
        }
        else {
            return false;
        }
    },
    //Determine if it is a positive integer (non-negative and 0), if it returns true, if not, it returns false
    plusInt: function (a) {//Positive integer
        var regx = /^[0-9]*[1-9][0-9]*$/;
        if (regx.test(a)) {
            return true;
        }
        else {
            return false;
        }
    },
    notMinusInt: function (a) {//Non-negative integer, an integer greater than or equal to 0
        var regx = /^(0|[1-9]\d*)$/;
        if (regx.test(a)) {
            return true;
        }
        else {
            return false;
        }
    },
    plusFloatInit: function (a) {//Non-negative floating point number
        var regx = /^\d+(\.\d+)?$/
        if (regx.test(a)) {
            return true;
        }
        else {
            return false;
        }
    },
    //Get the Url parameter
    getQry: function (name) {//Get page pass parameters
        var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
        var r = window.location.search.substr(1).match(reg);
        if (r != null) return (r[2]); return null;
    },
    //Determine if it is an empty string, if it returns true, if it is not, it returns false
    isNullOrEmpty: function (val) {//Judgment value is empty
        if (val == "" || val == null) {
            return true;
        }
        else {
            return false;
        }
    },
    //Determine if the message format is true. If it returns true, if it is not, it will return false.
    isEmail: function (val) {
        var myreg = /^([a-zA-Z0-9]+[\_|\_|\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/;
        if (!myreg.test(val)) {
            return false;
        }
        else {
            return true;
        }
    },
    //Check the password format (6~12 numbers or letters), if it returns true, if not, return false
    checkPassword: function (val) {
        var myreg = /^[a-zA-Z0-9]{6,12}$/;
        if (!myreg.test(val)) {
            return false;
        }
        else {
            return true;
        }
    },
    //Determine if it is an ID number. If it returns true, if it is not, it will return false.
    isIdCard: function (num) {
        var str = "";
        num = num.toUpperCase();
        //The ID number is 15 or 18 digits, all digits are 15 digits, the first 17 digits of 18 digits are numbers, and the last digit is a check digit, which may be a number or a character X.
        if (!(/(^\d{15}$)|(^\d{17}([0-9]|X)$)/.test(num))) {
            str = "输入的身份证号长度不对，或者号码不符合规定！\n15位号码应全为数字，\n18位号码末位可以为数字或X";
            return str;
        }
        //The check digit is generated in accordance with ISO 7064:1983.MOD 11-2, and X can be considered as the number 10.
        //The following is the analysis of the date of birth and the check digit
        var len, re;
        len = num.length;
        if (len == 15) {
            re = new RegExp(/^(\d{6})(\d{2})(\d{2})(\d{2})(\d{3})$/);
            var arrSplit = num.match(re);
            //Check if the birthday date is correct
            var dtmBirth = new Date('19' + arrSplit[2] + '/' + arrSplit[3] + '/' + arrSplit[4]);
            var bGoodDay;
            bGoodDay = (dtmBirth.getYear() == Number(arrSplit[2])) && ((dtmBirth.getMonth() + 1) == Number(arrSplit[3])) && (dtmBirth.getDate() == Number(arrSplit[4]));
            if (!bGoodDay) {
                str = "输入的身份证号里出生日期不对！";
                return str;
            }
            else {
                //Convert 15 ID cards to 18
                //The check digit is generated in accordance with ISO 7064:1983.MOD 11-2, and X can be considered as the number 10.
                var arrInt = new Array(7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2);
                var arrCh = new Array('1', '0', 'X', '9', '8', '7', '6', '5', '4', '3', '2');
                var nTemp = 0, i;
                num = num.substr(0, 6) + '19' + num.substr(6, num.length - 6);
                for (i = 0; i < 17; i++) {
                    nTemp += num.substr(i, 1) * arrInt[i];
                }
                num += arrCh[nTemp % 11];
                //return num;
            }
        }
        if (len == 18) {
            re = new RegExp(/^(\d{6})(\d{4})(\d{2})(\d{2})(\d{3})([0-9]|X)$/);
            var arrSplit = num.match(re);
            //Check if the birthday date is correct
            var dtmBirth = new Date(arrSplit[2] + "/" + arrSplit[3] + "/" + arrSplit[4]);
            var bGoodDay;
            bGoodDay = (dtmBirth.getFullYear() == Number(arrSplit[2])) && ((dtmBirth.getMonth() + 1) == Number(arrSplit[3])) && (dtmBirth.getDate() == Number(arrSplit[4]));
            if (!bGoodDay) {
                str = "输入的身份证号里出生日期不对！";
                return str;
            }
        }
        return str;
    },
    //Get the full path of a file
    getFullPath: function (path) {
        return "http://stq.v-hudong.cn" + path;
    },
    //Get thumbnail  
    getThumb: function (src) {
        if (src) {
            var tpath = src.substr(0, src.lastIndexOf('/')).replace("default", "thumb");
            var tname = "thumb_" + src.substr(src.lastIndexOf('/') + 1);
            return tpath + "/" + tname;
        } else {
            return src;
        }
    },
    //Get other size images of thumbnails
    getThumbOther: function (src, folderName) {
        if (src) {
            var tpath = src.substr(0, src.lastIndexOf('/')).replace("default", "thumb") + "/" + folderName;
            var tname = "thumb_" + src.substr(src.lastIndexOf('/') + 1);
            return tpath + "/" + tname;
        } else {
            return src;
        }
    },
    //Get the original image of other sizes
    getOtherImg: function (src, folderName) {
        if (src && src.indexOf('UploadFiles') > -1) {
            var path = src.substr(0, src.lastIndexOf('/')) + "/" + folderName;
            var name = src.substr(src.lastIndexOf('/') + 1);
            return path + "/" + name;
        } else {
            return src;
        }
    },
    /**
     * val A timestamp such as: /Date(1224043200000)/
     * mode: Format mode, if empty, the default is ("yyyy-mm-dd").
     * mode Optional value： {1or"d"：'yyyy-mm-dd'，2or"m"："yyyy-mm-dd HH:mm"，3or"h"：“HH:mm:ss”，4or"mm"：“mm:ss”,5: yyyy Year mm Month dd Day}
     */
    dateFormatStamp: function (val, mode) {
        if (val != null) {
            var date = new Date(parseInt(val.replace("/Date(", "").replace(")/", ""), 10));
            //The month is 0-11, so +1, when the month is less than 10, add 0
            var month, day, hour, minute, second;
            month = date.getMonth() + 1 < 10 ? "0" + (date.getMonth() + 1) : date.getMonth() + 1;
            day = date.getDate() < 10 ? "0" + date.getDate() : date.getDate();
            hour = date.getHours() < 10 ? "0" + date.getHours() : date.getHours();
            minute = date.getMinutes() < 10 ? "0" + date.getMinutes() : date.getMinutes();
            second = date.getSeconds() < 10 ? "0" + date.getSeconds() : date.getSeconds();
            if (mode == 1 || mode == 'd') {
                return date.getFullYear() + "-" + month + "-" + day;
            } else if (mode == 2 || mode == 'm') {
                return date.getFullYear() + "-" + month + "-" + day + " " + hour + ":" + minute;
            } else if (mode == 3 || mode == 'h') {
                return hour + ":" + minute + ":" + second;
            } else if (mode == 4 || mode == 'mm') {
                return minute + ":" + second;
            }
            else if (mode == 5) {
                return date.getFullYear() + "年" + month + "月" + day + "日"
            }

            else {
                return date.getFullYear() + "-" + month + "-" + day + " " + hour + ":" + minute + ":" + second;
            }
        }
        return "";
    },
    dateFormat: function (val, mode) {
        if (val != null) {
            var date = new Date(val.replace(" ", "T"));
            //The month is 0-11, so +1, when the month is less than 10, add 0
            var month, day, hour, minute, second;
            month = date.getMonth() + 1 < 10 ? "0" + (date.getMonth() + 1) : date.getMonth() + 1;
            day = date.getDate() < 10 ? "0" + date.getDate() : date.getDate();
            hour = date.getHours() < 10 ? "0" + date.getHours() : date.getHours();
            minute = date.getMinutes() < 10 ? "0" + date.getMinutes() : date.getMinutes();
            second = date.getSeconds() < 10 ? "0" + date.getSeconds() : date.getSeconds();
            if (mode == 1 || mode == 'd') {
                return date.getFullYear() + "-" + month + "-" + day;
            } else if (mode == 2 || mode == 'm') {
                return date.getFullYear() + "-" + month + "-" + day + " " + hour + ":" + minute;
            } else if (mode == 3 || mode == 'h') {
                return hour + ":" + minute + ":" + second;
            } else if (mode == 4 || mode == 'mm') {
                return minute + ":" + second;
            }
            else if (mode == 5) {
                return date.getFullYear() + "年" + month + "月" + day + "日"
            }

            else {
                return date.getFullYear() + "-" + month + "-" + day + " " + hour + ":" + minute + ":" + second;
            }
        }
        return "";
    },
    dateDifferDay: function (date) {
        var s1 = date;
        s1 = new Date(s1.replace(/-/g, "/"));
        s2 = new Date();
        var days = s1.getTime() - s2.getTime();
        var time = parseInt(days / (1000 * 60 * 60 * 24));
        return time;
    }
});


//Scale the image proportionally
function AutoResizeImage(maxWidth, maxHeight, objImg) {
    var img = new Image();
    img.src = objImg.src;
    var hRatio;
    var wRatio;
    var Ratio = 1;
    var w = img.width;
    var h = img.height;
    wRatio = maxWidth / w;
    hRatio = maxHeight / h;
    if (maxWidth == 0 && maxHeight == 0) {
        Ratio = 1;
    } else if (maxWidth == 0) {//
        if (hRatio < 1) Ratio = hRatio;
    } else if (maxHeight == 0) {
        if (wRatio < 1) Ratio = wRatio;
    } else if (wRatio < 1 || hRatio < 1) {
        Ratio = (wRatio <= hRatio ? wRatio : hRatio);
    }
    if (Ratio < 1) {
        w = w * Ratio;
        h = h * Ratio;
    }
    objImg.height = h;
    objImg.width = w;
}
//format: 1:12-01-01 13:00 ,2:2012-01-01 13:00:00,3:2012-01-01 13:00:
function getdatetime(val, format) {
    val = val.replace(/-/g, "/");
    var date = new Date(val);
    var year = date.getFullYear();
    var month = (date.getMonth() + 1) < 10 ? "0" + (date.getMonth() + 1) : date.getMonth() + 1;
    var day = date.getDate() < 10 ? "0" + date.getDate() : date.getDate();
    var hh = date.getHours() < 10 ? "0" + date.getHours() : date.getHours();
    var mm = date.getMinutes() < 10 ? "0" + date.getMinutes() : date.getMinutes();
    var ss = date.getSeconds() < 10 ? "0" + date.getSeconds() : date.getSeconds();

    if (format == 1) {
        return year.toString().substring(2) + "-" + month + "-" + day + " " + hh + ":" + mm;
    } else if (format == 2) {
        return year + "-" + month + "-" + day + " " + hh + ":" + mm + ":" + ss;
    }
    else if (format == 3) {
        return year + "-" + month + "-" + day + " " + hh + ":" + mm;
    }
    else if (format == 4) {
        return year + "-" + month + "-" + day;
    }
}
//Get date description
function getdatedescription(val, format) {
    var curdate = new Date();
    val = val.replace(/-/g, "/");
    var date = new Date(val);
    var year = date.getFullYear();
    var month = (date.getMonth() + 1) < 10 ? "0" + (date.getMonth() + 1) : date.getMonth() + 1;
    var day = date.getDate() < 10 ? "0" + date.getDate() : date.getDate();
    var hh = date.getHours() < 10 ? "0" + date.getHours() : date.getHours();
    var mm = date.getMinutes() < 10 ? "0" + date.getMinutes() : date.getMinutes();
    var ss = date.getSeconds() < 10 ? "0" + date.getSeconds() : date.getSeconds();
    if (curdate.getFullYear() == date.getFullYear() && curdate.getMonth() == date.getMonth()) {
        if ((curdate.getDate() - date.getDate()) == 0 && format == 1) {
            return "今天"
        }
        else if ((curdate.getDate() - date.getDate()) == 0 && format == 2) {
            return "今天 " + hh + ":" + mm;
        }
        else if ((curdate.getDate() - date.getDate()) == 1 && format == 3) {
            return "昨天";
        }
        else if ((curdate.getDate() - date.getDate()) == 1 && format == 4) {
            return "昨天" + hh + ":" + mm;;
        }
        else {
            return year + "-" + month + "-" + day;
        }
    }
    else {
        return year + "-" + month + "-" + day;
    }
}
function getCookie(name) {
    var arr, reg = new RegExp("(^| )" + name + "=([^;]*)(;|$)");
    if (arr = document.cookie.match(reg))
        return unescape(arr[2]);
    else
        return null;
}


Math.floatAdd = function (arg1, arg2) {
    var r1, r2, m;
    try { r1 = arg1.toString().split(".")[1].length } catch (e) { r1 = 0 }
    try { r2 = arg2.toString().split(".")[1].length } catch (e) { r2 = 0 }
    m = Math.pow(10, Math.max(r1, r2));
    return (arg1 * m + arg2 * m) / m;
}

//Less    
Math.floatSub = function (arg1, arg2) {
    var r1, r2, m, n;
    try { r1 = arg1.toString().split(".")[1].length } catch (e) { r1 = 0 }
    try { r2 = arg2.toString().split(".")[1].length } catch (e) { r2 = 0 }
    m = Math.pow(10, Math.max(r1, r2));
    //Dynamic control accuracy length    
    n = (r1 >= r2) ? r1 : r2;
    return ((arg1 * m - arg2 * m) / m).toFixed(n);
}

//Multiply    
Math.floatMul = function (arg1, arg2) {
    var m = 0, s1 = arg1.toString(), s2 = arg2.toString();
    try { m += s1.split(".")[1].length } catch (e) { }
    try { m += s2.split(".")[1].length } catch (e) { }
    return Number(s1.replace(".", "")) * Number(s2.replace(".", "")) / Math.pow(10, m);
}


//except   
Math.floatDiv = function (arg1, arg2) {
    var t1 = 0, t2 = 0, r1, r2;
    try { t1 = arg1.toString().split(".")[1].length } catch (e) { }
    try { t2 = arg2.toString().split(".")[1].length } catch (e) { }

    r1 = Number(arg1.toString().replace(".", ""));

    r2 = Number(arg2.toString().replace(".", ""));
    return (r1 / r2) * Math.pow(10, t2 - t1);
}