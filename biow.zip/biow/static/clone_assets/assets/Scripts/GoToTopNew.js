﻿/*
 * 功能：回到页面顶部
 * 时间：2015-1-28
 * 作者：李建峰
 */
$(document).ready(function () {
    //滚动条事件
    $(window).scroll(function () {
        var $top = $("a[href='#top']");
        if ($(window).scrollTop() > 0) {
            $top.show();
        }
        else {
            $top.hide();
        }
    });
    //显示菜单
    $("#icon_menu_open").click(function () {
        $("#right_menu_box").attr("class", "right_menu_box1").focus();
        $(this).hide();
        $("#icon_menu_close").show();
        $(".right_menu").show();
    });
    //关闭菜单
    $("#icon_menu_close").click(function () {
        $("#right_menu_box").attr("class", "right_menu_box");
        $(this).hide();
        $("#icon_menu_open").show();
    });
    $(".right_menu").mouseleave(function () {
        $("#right_menu_box").attr("class", "right_menu_box");
        $(this).hide();
        $("#icon_menu_open").show();
    });

})