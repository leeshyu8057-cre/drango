﻿(function ($) {
    $.Url = function (url) {
        var proc = function (href) {
            //返回对象。Jquery Json Url
            var jurl = {};
            jurl.root = (window.Root || "");
            jurl.href = href;
            jurl.kv = {};
            jurl.search = "";

            if (jurl.href === "") {
                jurl.root = "";
            }
            else {
                var ind, isProtocol = jurl.href.indexOf("://");
                if (isProtocol > 0) {
                    ind = jurl.href.indexOf("/", isProtocol + 3);
                    jurl.root = jurl.href.substr(0, ind) + "";
                }
                else if (jurl.href.indexOf("~/") == 0) {
                    jurl.href = "" + jurl.href.slice(2);
                }
            }

            jurl.attr = function (key, value) {
                if (value) {
                    jurl.kv[key] = value;
                    return jurl;
                }
                else return jurl.kv[key];
            }
            jurl.removeAttr = function (key) {
                delete this.kv[key];
                return this;
            }
            jurl.tohref = function () {
                if (this.href === "") return "";

                var retVal = this.url,
                    queryAry = [];
                $.each(GetJsonKeys(this.kv), function (i, d) {
                    if (!d) return;
                    queryAry.push(encodeURIComponent(d) + "=" + (!jurl.kv[d] ? "" : encodeURIComponent(jurl.kv[d])));
                });
                return retVal + (queryAry.length > 0 ? "?" : "") + queryAry.join("&");
            }
            jurl.toString = jurl.tohref;
            if (!jurl.href) return jurl;
            var seg1 = jurl.href.indexOf("?");
            if (seg1 >= 0) {
                jurl.url = jurl.href.slice(0, seg1);
                jurl.search = jurl.href.slice(seg1);
                var seg2 = jurl.search.slice(1);
                if (seg2) {
                    var seg3 = seg2.split('&');
                    $.each(seg3, function () {
                        var seg4 = this.split('='),

                            key = decodeURIComponent(seg4[0]),
                            value = !seg4[1] ? "" : decodeURIComponent(seg4[1]);
                        jurl.kv[key] = value;
                    });
                }
            }
            else { jurl.url = jurl.href; }

            //返回从虚拟路径开始的伪虚拟URL。对于Mvc来说，是一个  Area/Controller/Action/Id 的地址。
            jurl.path = jurl.url.slice(jurl.root.length);
            return jurl;
        };
        if (url === "") {
            return proc("");
        } else if (url) {
            return proc(url.toString());
        }
        else return proc(window.href || (window.location && window.location.href));
    };

    var GetJsonKeys = getJsonKeys = function (Dict) {
        var ret = [];
        if (!Dict) return ret;
        for (var p in Dict) {
            if (!Dict.hasOwnProperty(p)) continue;
            if ($.isFunction(p)) continue;
            ret.push(p);
        }
        return ret;
    }

    $.timer = function (interval, callback) {
        var interval = interval || 100;
        if (!callback)
            return false;

        var doer = "";
        _timer = function (interval, callback) {
            var self = this;
            this.stop = function () {
                clearInterval(self.id);
            };

            this.reset = function (val) {
                if (self.id)
                    clearInterval(self.id);

                var val = val || 100;
                this.id = setInterval(function () { callback(self, { originalEvent: true, target: doer }) }, val);
            };

            this.interval = interval;
            this.id = setInterval(function () { callback(self, { originalEvent: true, target: doer }) }, this.interval);

            return this.id;
        };

        return new _timer(interval, callback);
    };

    $.randomNum = function (minNum, maxNum) {
        switch (arguments.length) {
            case 1:
                return parseInt(Math.random() * minNum + 1, 10);
                break;
            case 2:
                return parseInt(Math.random() * (maxNum - minNum + 1) + minNum, 10);
                break;
            default:
                return 0;
                break;
        }
    }

    $.alert = function (msg, type, times) {
        $.WebUI.toast(msg, type || "warning", times);

    }
    $.confirm = function (msg, title, sureHandler, cancelHandler) {
        $.WebUI.dialog({
            title: title,
            content: msg,
            buttons: [{
                text: '取消',
                handler: function () {
                    if (cancelHandler && typeof cancelHandler == "function") {
                        cancelHandler.call();
                    }
                    $.WebUI.closedialog();
                }
            }, {
                text: '确定',
                clsname: "primary",
                handler: function () {
                    if (sureHandler && typeof sureHandler == "function") {
                        sureHandler.call();
                    }
                    $.WebUI.closedialog();
                }
            }]
        });
    }
    $.confirm2 = function (option) {
        var optionDefalut = {
            msg: "",
            title: "",
            sureText: "确定",
            sureHandler: null,
            cancelText: "取消",
            cancelHandler: null
        }
        option = $.extend(optionDefalut, option)
        var buttons = [];
        if (option.cancelText) {
            buttons.push({
                text: option.cancelText,
                handler: function () {
                    if (option.cancelHandler && typeof option.cancelHandler == "function") {
                        option.cancelHandler.call();
                    }
                    $.WebUI.closedialog();
                }
            });
        }
        buttons.push({
            text: option.sureText,
            clsname: "primary",
            handler: function () {
                if (option.sureHandler && typeof option.sureHandler == "function") {
                    option.sureHandler.call();
                }
                $.WebUI.closedialog();
            }
        })
        $.WebUI.dialog({
            title: option.title,
            content: option.msg,
            buttons: buttons
        });
    }
    //可输入的下拉选框
    $.fn.Select3 = $.fn.select3 = function (data) {
        var selector = this.selector;
        var id = selector.replace(/[#.:'"\s-=\(\)\[\]]/g, "");
        var selListId = id + "SelectList";
        if ($(this).length > 0) {
            $(this).attr("data-id", "");
            $(this).val("");
            $(this).siblings("[name='h_" + id + "']").val("");
            $(this).siblings(".Sel_option").remove();
        } else {
            return;
        }
        if (!(data instanceof Array)) {
            return;
        }
        if (data.length <= 0) {
            return;
        }
        if ($(this).closest(".Sel_box").length <= 0) {
            $(this).wrap('<div class="Sel_box"></div>');
            $(this).closest(".Sel_box").append('<input type="hidden" name="h_' + id + '"  />')
        }


        var w = $(this).outerWidth();
        var shtml = '<div id="' + selListId + '" class="Sel_option" style="width:' + w + 'px;"><ul>';
        for (var i = 0; i < data.length; i++) {
            shtml += '<li data-id="' + data[i].id + '">' + data[i].name + '</li>';
        }
        shtml += '</ul></div>';
        $(this).closest(".Sel_box").find(".Sel_option").remove();
        $(this).closest(".Sel_box").append(shtml);
        $("#" + selListId).css("padding-top", $(this).css("padding-top"));
        $("#" + selListId).css("padding-right", $(this).css("padding-right"));
        $("#" + selListId).css("padding-bottom", $(this).css("padding-bottom"));
        $("#" + selListId).css("padding-left", $(this).css("padding-left"));
        $("#" + selListId).css("top", $(this).outerHeight());

        var flag1 = 0;
        var pos = -1;
        var input = $(this);
        var inputDom = $(this)[0];
        function init() {
            var t;
            hide();
            bindInput();

            var sel_op = $("#" + selListId);
            sel_op.find("li").unbind("mouseup").mouseup(function (e) {
                if (t) {
                    clearInterval(t);
                };
                var str = $(this).text();
                var id = $(this).attr("data-id");
                setValue(input, id, str);
            });


            sel_op.find("li").unbind("mousemove").mousemove(function (e) {
                $flag1 = 1;
            });


            input.unbind("focus").focus(function () {
                $flag1 = 0;
                show1();
            });

            input.unbind("blur").blur(function () {
                if (!$flag1) {
                    hide();
                    var s_value = input.val();
                    var dataid = "";
                    sel_op.children().children("li").each(function () {
                        var tmp = $(this).text().substr(0, $(this).text().length);
                        if (tmp && s_value.trim() == tmp) {
                            dataid = $(this).attr("data-id");
                        }
                    });
                    input.attr("data-id", dataid)
                    input.siblings("[name='h_" + id + "']").val(dataid);
                } else {
                    t = setTimeout(function () {
                        hide();
                    }, 300);
                }
            });
        }

        function bindInput() {
            //IE
            if (window.ActiveXObject) {
                //document.getElementById('s_custemail').attachEvent("onpropertychange", show1);
                inputDom.attachEvent("onpropertychange", show1);
            } else {
                input.bind("input", show1);
            }
        }

        function show1() {
            var s_value = input.val().trim();
            $("#" + selListId).children().children("li").hide();
            showListEmail();
            if (s_value.length >= 1) {
                $("#" + selListId).children().children("li").each(function () {
                    var tmp = $(this).text().substr(0, $(this).text().length);
                    if (tmp && tmp.indexOf(s_value) >= 0) {
                        $(this).show();
                    }
                });
            } else {
                $("#" + selListId).children().children("li").show();
            }
        }
        function hide() {
            $("#" + selListId).css("display", "none");
        }
        function setValue(obj, dataid, str) {
            obj.val(str);
            obj.attr("data-id", dataid)
            obj.siblings("[name='h_" + id + "']").val(dataid);
            hide();
            //obj.focus();
        }
        function showListEmail() {
            var obj = input;
            $("#" + selListId).css('display', 'block');
        }
        init();
    }

    $.AutoTimer = function (opts) {
        var p = $.extend({}, $.AutoTimer.defaults, opts);
        if (!p.CycleCallBack || !p.EndAt || !p.StartAt) return;
        if (typeof p.CycleCallBack != "function") return;

        var intDiff = p.EndAt - p.StartAt;
        if (!intDiff) return;
        if (intDiff == 0) {
            if (typeof p.CompleteCallBack == "function") {
                p.CompleteCallBack(p.timer);
            }
            return;
        }
        p.timer = $.timer(p.Millisec, function () {
            intDiff -= p.Millisec;
            var day = 0,
                hour = 0,
                minute = 0,
                second = 0;
            millisecond = 0;
            if (intDiff > 0) {
                day = parseInt(intDiff / 1000 / 60 / 60 / 24, 10);
                hour = parseInt(intDiff / 1000 / 60 / 60 % 24, 10);
                minute = parseInt(intDiff / 1000 / 60 % 60, 10);
                second = parseInt(intDiff / 1000 % 60, 10);
                millisecond = parseInt(intDiff % 1000, 10);
            }
            else {
                if (typeof p.CompleteCallBack == "function") {
                    p.CompleteCallBack(p.timer);
                }

            }
            if (hour <= 9) hour = '0' + hour;
            if (minute <= 9) minute = '0' + minute;
            if (second <= 9) second = '0' + second;
            var timeData = { Day: day, Hour: hour, Minute: minute, Second: second, Millisecond: millisecond };
            p.CycleCallBack(timeData, p.timer);
        });

        return p;
    };

    $.AutoTimer.defaults = {
        StartAt: null,
        EndAt: null,
        Millisec: 1000,//timer周期（毫秒）,
        CycleCallBack: null,
        CompleteCallBack: null,
        timer: null
    };

    $.GetTimerSpan = $.gettimeSpan = function (edate, sdate) {

        var intDiff = edate - sdate;
        var day = 0,
            hour = 0,
            minute = 0,
            second = 0;
        if (intDiff > 0) {
            var day = parseInt(intDiff / 1000 / 60 / 60 / 24, 10);
            var hour = parseInt(intDiff / 1000 / 60 / 60 % 24, 10);
            var minute = parseInt(intDiff / 1000 / 60 % 60, 10);
            var second = parseInt(intDiff / 1000 % 60, 10);
        }
        if (hour <= 9) hour = '0' + hour;
        if (minute <= 9) minute = '0' + minute;
        if (second <= 9) second = '0' + second;

        return { Day: day, Hour: hour, Minute: minute, Second: second };
    };
})(jQuery)



Date.prototype.Format = function (fmt) {
    var o = {
        "M+": this.getMonth() + 1,                 //月份 
        "d+": this.getDate(),                    //日 
        "h+": this.getHours(),                   //小时 
        "m+": this.getMinutes(),                 //分 
        "s+": this.getSeconds(),                 //秒 
        "q+": Math.floor((this.getMonth() + 3) / 3), //季度 
        "S": this.getMilliseconds()             //毫秒 
    };
    if (/(y+)/.test(fmt)) {
        fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
    }
    for (var k in o) {
        if (new RegExp("(" + k + ")").test(fmt)) {
            fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
        }
    }
    return fmt;
}
if (!Array.prototype.filter) {
    Array.prototype.filter = function (callback) {
        // 获取数组长度
        var len = this.length;
        if (typeof callback != "function") {
            throw new TypeError();
        }
        // 创建新数组，用于承载经回调函数修改后的数组元素
        var newArr = new Array();
        // thisArg为callback 函数的执行上下文环境
        var thisArg = arguments[1];
        for (var i = 0; i < len; i++) {
            if (i in this) {
                if (callback.call(thisArg, this[i], i, this)) {
                    newArr.push(val);
                }
            }
        }
        return newArr;
    }
}

Array.prototype.find = function (key, val) {
    var len = this.length;
    if (len > 0) {
        for (var i = 0; i < len; i++) {
            if (typeof this[i] == "object") {
                if (this[i][key] == val) {
                    return this[i];
                }
            }
        }
    }
    return null;
}

