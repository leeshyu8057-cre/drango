﻿/// <reference path="../../../../Themes/Jquery/jquery-1.11.1.min.js" />
/// <reference path="../jquery.productCas.js" />
inquiryConst = {
    invalid: -1,
    china: 4,
    otherProvice: 36
}

var SearchCas;

/*
 * 功能：需求量
 * 参数：number--数量，unit--单位
 * 时间：2016-3-14
 * 作者：李建峰
 */
function Required(number, unit) {
    var number = number;
    /*
     * 获取数量
     */
    this.getNumber = function () {
        return number;
    }
    var unit = unit;
    /*
     * 获取单位
     */
    this.getUnit = function () {
        return unit;
    }
    var message;
    /*
     * 获取提示信息
     */
    this.getMessage = function () {
        return message;
    }
    /*
     * 验证,true--验证通过,false-验证失败
     */
    this.validate = function () {
        var patter = /^([0-9]+|[0-9]+\.[0-9]+)$/;
        if (!patter.test(number)) {
            message = "需求量只能填写数字";
            return false;
        }
        else {
            if (parseFloat(number) == 0) {
                message = "需求量必须大于0";
                return false;
            }
        }
        return true;
    }
}
/*
 * 功能：询单
 * 参数：productName--产品名称
 *       cityId--收货地址
 * 时间：2016-3-14
 * 作者：李建锋
 */
function Inquiry(productName, cityId) {
    var productName = productName;
    var InquiryModel;
    /*
     * 获取产品名称
     */
    this.getProductName = function () {
        return productName;
    }
    var cityId = cityId;
    /*
     * 获取城市
     */
    this.getCityId = function () {
        return cityId;
    }
    var _cas, _note;
    /*
     * 设置Cas
     */
    this.setCas = function (cas) {
        _cas = cas;
    }
    /*
     * 设置Note
     */
    this.setNote = function (note) {
        _note = note;
    }
    this.getNote = function () {
        return _note;
    }
    var _purityId;
    this.setPurityId = function (purityId) {
        _purityId = purityId;
    }
    this.getPurityId = function () {
        return _purityId;
    }
    var _purity;
    this.setPurity = function (purity) {
        _purity = purity;
    }
    this.getPurity = function () {
        return _purity;
    }
    var _invoiceType;
    /*
     * 设置_invoiceType
     */
    this.setInvpiceType = function (invoiceType) {
        _invoiceType = invoiceType;
    }
    /*
     * 获取InvoiceType
     */
    this.getInvpiceType = function () {
        return _invoiceType;
    }

    var _requireds = [];
    /*
     * 设置需求量
     */
    this.setRequired = function (required) {
        _requireds.push(required);
    }
    var _publicContact;
    /*
     * 设置是否公开联系方式
     */
    this.setPublicContact = function (publicContact) {
        _publicContact = publicContact;
    }

    var _customized;
    this.getCustomized = function () {
        return _customized;
    }
    this.setCustomized = function (customized) {
        _customized = customized;
    }
    var _deliveryDay;
    this.getDeliveryDay = function () {
        return _deliveryDay;
    }
    this.setDeliveryDay = function (deliveryDay) {
        _deliveryDay = deliveryDay;
    }
    var _message = [];
    /*
     * 获取提示信息
     */
    this.getMessage = function () {
        return _message;
    }

    this.getInquiryModel = function () {
        return InquiryModel;
    }

    /*
     * 验证
     */
    this.validate = function () {
        var success = true;
        //if (!productName) {
        //    success = false;
        //    _message.push("产品名称必须填写");
        //}
        if (_cas) {
            if (!$.isCas(_cas)) {
                success = false;
                _message.push("无效Cas");
            }
        }
        if (!productName && !_cas) {
            success = false;
            _message.push("产品名称和CAS必须两个填写一个");
        }
        if (_requireds.length == 0) {
            success = false;
            _message.push("请填写需求量");
        }
        var len = _requireds.length;
        var items = [];
        for (var i = 0; i < len; i++) {
            var _required = _requireds[i];
            if (!_required.validate()) {
                success = false;
                _message.push(_required.getMessage());
            }
            items.push({ Number: _required.getNumber(), Unit: { Id: _required.getUnit() } });
        }
        if (cityId == inquiryConst.invalid) {
            success = false;
            _message.push("请选择地址，以便得到最好的报价");
        }
        //if (!_invoiceType || _invoiceType == -1) {
        //    success = false;
        //    _message.push("请选择发票类型");
        //}

        if (_customized) {
            if (_deliveryDay <= 0) {
                success = false;
                _message.push("请选择货期");
            }
        }

        if (_note) {
            if (_note.length > 60) {
                success = false;
                _message.push("备注最多60个字符");
            }
        }

        var uiSource = $("#uisource").val();
        if (!uiSource) {
            uiSource = "M";
            if (window.navigator.userAgent.toLowerCase().match(/MicroMessenger/i) == "micromessenger") {
                uiSource = "Wechat";
            }
        }
        InquiryModel = { ProductName: productName, Cas: _cas, PurityId: _purityId || 0, Purity: _purity, CityId: cityId, Remark: _note, PublishContact: _publicContact, Items: items, InvoiceTypeId: 6, UISource: uiSource, customized: _customized, deliveryDay: _deliveryDay };
        if (!success) {
            return success;
        }
        else {
            var cookieUserName = getCookie("userName") || getCookie("_userName") || "";
            if (cookieUserName != "") {//已登录
                return true;
            }
            else {//未登录，跳转登录
                var arrInquiry, regInquiry = new RegExp("(^| )" + "InquiryStr" + "=([^;]*)(;|$)");
                var cookieInquiry = "";
                if (arrInquiry = document.cookie.match(regInquiry)) {
                    cookieInquiry = unescape(arrInquiry[2]);
                }
                if (cookieInquiry != "") {
                    delCookie('InquiryStr');
                    setCookie('InquiryStr', JSON.stringify(InquiryModel));
                    window.location.href = "/UserManager/Login.aspx?ReturnUrl=" + encodeURIComponent(window.location.href) + "&type=1";
                }
                else {
                    setCookie('InquiryStr', JSON.stringify(InquiryModel));
                    window.location.href = "/UserManager/Login.aspx?ReturnUrl=" + encodeURIComponent(window.location.href) + "&type=1";
                }
            }
        }
    }
}
function setCookie(name, value) {
    var Days = 1;
    var exp = new Date();
    exp.setTime(exp.getTime() + Days * 24 * 60 * 60 * 1000);
    document.cookie = name + "=" + escape(value) + ";expires=" + exp.toGMTString() + ";path= /";
}
function delCookie(name) {
    var exp = new Date();
    exp.setTime(exp.getTime() - 1);
    var cval = getCookie(name);
    if (cval != null)
        document.cookie = name + "=" + cval + ";expires=" + exp.toGMTString() + ";path= /";
}

/*
 * 功能：新增采购视图
 * 时间：2015-3-14
 * 作者：李建锋
 */
function AddInquiryView($elementProductName, $elementCas, $elementPurity, $elementCity, $elementNote, elementRequireds, elementInvoiceType, elementCustomized, elementDeliveryDay) {
    var _message = [];
    var InquiryModel;
    /*
     * 获取提示信息
     */
    this.getMessage = function () {
        return _message;
    }
    /*
     * 验证
     * 参数：
     * $elementProductName--产品名称元素
     * $elementCas--Cas
     * $elementCity--收货地址
     * $elementNote--备注
     * $elementPublic--不公开
     * elementRequireds--需求量集合,[{number:$elment,unit:$element}]
     */
    this.Save = function (send) {
        var productName = $elementProductName.val();
        var cityId = $elementCity.val();
        var inquiry = new Inquiry(productName, cityId);
        inquiry.setCas($.trim($elementCas.val()));
        inquiry.setPurityId($.trim($elementPurity.attr("data-id")));
        inquiry.setPurity($.trim($elementPurity.val()));

        inquiry.setCustomized(elementCustomized.prop("checked"));
        inquiry.setDeliveryDay(elementDeliveryDay.val() || 0);

        //inquiry.setInvpiceType(elementInvoiceType.val());
        inquiry.setNote($.trim($elementNote.val()));
        inquiry.setPublicContact(false);
        var len = elementRequireds.length;
        for (var i = 0; i < len; i++) {
            var elemenrRequired = elementRequireds[i];
            if (elemenrRequired.number.val() && elemenrRequired.unit.val()) {
                inquiry.setRequired(new Required($.trim(elemenrRequired.number.val()), $.trim(elemenrRequired.unit.val())));
            }

        }
        var success = inquiry.validate();
        _message = inquiry.getMessage();
        InquiryModel = inquiry.getInquiryModel();
        if (success) {
            send.prop("disabled", true);
            $.ajax({
                url: "/PurchaseHelper/Purchase/AddInquiry",
                type: "post",
                data: { inquiryStr: JSON.stringify(InquiryModel) },
                dataType: "json",
                success: function (json) {
                    if (json.code == 0) {
                        //$.alert("询价成功!可前去询价管理中查看您的询单", "success");
                        window.location.href = "/Purchasehelper/Purchase/WaitQuote";
                    } else {
                        $("#err").html(json.msg).show();
                    }
                },
                complete: function () {
                    send.prop("disabled", false);
                }
            });
        } else {
            this.displayMessage($("#err"));
        }
        return success;
    }

    /*
     * 显示提示信息
     */
    this.displayMessage = function ($element) {
        var lenMessage = _message.length;
        $element.html("").hide();
        if (lenMessage > 0) {
            $element.html(_message.join("<br />")).show();
        }
    }
}
/*
 * 功能：收货地址视图
 */
function ReceiveAddressView($element) {
    var level = 2;
    $.ajax({
        url: "/City/GetCountryProvinceCity",
        type: "Post",
        data: { "language": "zh-cn", level: level },
        dataType: "json",
        success: function (data) {
            //重新组合数据
            var len = data.length;
            var otherIndex = inquiryConst.invalid;
            for (var i = 0; i < len; i++) {
                var country = data[i];
                //if (country.pid == inquiryConst.china) {
                var province = country.c;
                if (province) {

                    var lenProvince = province.length;

                    for (var j = 0; j < lenProvince; j++) {
                        var city = province[j].a;
                        if (city) {
                            city.splice(0, 0, { sid: -1, s: "请选择" });
                        }
                        //else {
                        //    province[j].a = [{ sid: -1, s: "请选择" }];
                        //}
                    }
                    if (level == 2) {
                        province.splice(0, 0, { nid: -1, n: "请选择" });
                    } else {
                        province.splice(0, 0, { nid: -1, n: "请选择", a: [{ sid: -1, s: "请选择" }] });
                    }
                }
                if (country.pid == inquiryConst.otherProvice) {
                    otherIndex = i;
                }
                //}
            }
            if (otherIndex > inquiryConst.invalid) {
                data.splice(otherIndex, 1);
            }
            if (level == 2) {
                data.splice(0, 0, { pid: -1, p: "请选择", c: [{ nid: -1, n: "请选择" }] });
            } else {
                data.splice(0, 0, { pid: -1, p: "请选择", c: [{ nid: -1, n: "请选择", a: [{ sid: -1, s: "请选择" }] }] });
            }

            var cityObj = localStorage.getItem("delegateinquiry_city");
            if (!cityObj) {
                cityObj = { prov: -1, city: -1 }
            } else {
                cityObj = JSON.parse(cityObj);
            }

            $element.citySelect({
                url: {
                    "citylist": data
                },
                prov: cityObj.prov,
                city: cityObj.city,
                dist: -1,
                nodata: "none"
            });
            setTimeout(function () {
                $("[name='sl_city']").unbind().change(function () {
                    var sProv = $(this).parent().find("[name='sl_prov']").val() || -1;
                    var sCity = $(this).parent().find("[name='sl_city']").val() || -1;
                    localStorage.setItem("delegateinquiry_city", JSON.stringify({ prov: sProv, city: sCity }));
                });
            }, 1000);
        }
    });
}
/*
 * 初始化界面
 */
$(document).ready(function () {
    var url = $.Url();
    if (url.kv.msg) {
        $("#err").html(url.kv.msg).show();
    }
    //var delegateinquiry_invoicetype = localStorage.getItem("delegateinquiry_invoicetype") || -1;
    //$("[name='invoiceType']").val(delegateinquiry_invoicetype);
    //$("[name='invoiceType']").unbind().change(function () {
    //    localStorage.setItem("delegateinquiry_invoicetype", $(this).val());
    //});

    ReceiveAddressView($("#citySpan"));
    $(":text[name='it_cas']").blur(function () {
        var cas = $(this).val().trim();
        $(this).val(cas);
        $("[name='it_productname']").val("");
        //PurityBind(cas);
        //if (!cas) {
        //    return;
        //}
        //if (cas == SearchCas) {
        //    return;
        //}
        //SearchCas = cas;
        //$.ajax({
        //    url: "/PurchaseHelper/Purchase/GetProductNameFromCas",
        //    type: "Post",
        //    data: { cas: cas },
        //    success: function (data) {
        //        $(":text[name='it_productname']").val(data);
        //    }
        //});
    });
    $("[name='it_productname']").unbind().change(function () {
        $("[name='it_cas']").val("");
    });
    $(".select_product").unbind().change(function () {
        var p_name = $(this).val();
        if (p_name == "cas") {
            // $(this).css("paddingLeft", "25px")
            $("[name='it_cas']").show();
            $("[name='it_productname']").hide();
        } else {
            //$(this).css("paddingLeft", "0");
            $("[name='it_productname']").show();
            $("[name='it_cas']").hide();
        }
    });
    $(":input[data-save]").click(function () {
        var requireds = [];
        requireds.push({ number: $(":text[name='it_required_first']"), unit: $("select[name='sl_required_first_unit']") });
        requireds.push({ number: $(":text[name='it_required_sencond']"), unit: $("select[name='sl_required_sencond_unit']") });
        var addInquiryView = new AddInquiryView($(":text[name='it_productname']"), $(":text[name='it_cas']"), $(":text[name='it_purity']"), $("select[name='sl_city']"), $("[name='it_note']"), requireds, null, $("[name='customized']"), $("[name='deliveryDay']:checked"));
        var success = addInquiryView.Save($(this));

        return success;
    });

    //var cas = $("[name='it_cas']").val().trim();
    //if (cas) {
    //    PurityBind(cas);
    //}


    $("[data-btn-batch]").unbind().click(function () {
        $("#err").html("").hide();
        var batch = $(this).attr("data-btn-batch");
        if (batch == "true") {
            var text = localStorage.getItem("batch_inquiry_content");
            if (text) {
                $('[name="it_batch_content"]').val(text);
            }
            $("[data-batch='true']").show();
            $("[data-batch='false']").hide();
        } else {
            $("[data-batch='false']").show();
            $("[data-batch='true']").hide();
        }
    });
    $('[name="it_batch_content"]').blur(function () {
        var text = $(this).val();
        localStorage.setItem("batch_inquiry_content", text);
    });
    $('[data-batch-save="true"]').unbind().click(function () {
        var _this = $(this);
        var text = $('[name="it_batch_content"]').val();
        var source = "";//$(":hidden[data-field='source']").val();
        var source = "M";
        if (window.navigator.userAgent.toLowerCase().match(/MicroMessenger/i) == "micromessenger") {
            source = "Wechat";
        }
        var cityId = $("select[name='sl_city']>:selected").val();
        //var invoiceType = $("[name='invoiceType']").val();
        var note = $('[data-field="remark"]').val();
        var success = true;
        var msg = [];
        var msg_ele = [];
        if (!text) {
            success = false;
            msg.push("请填写产品");
            msg_ele.push("batch_content");
        } else {
            var products = text.split("\n");
            for (var i = 0; i < products.length; i++) {
                if (!products[i].trim()) {
                    continue;
                }
                var p_g = products[i].split(',');
                if (p_g.length != 2) {
                    msg.push("第" + (i + 1) + "行产品填写不正确");
                    msg_ele.push("batch_content");
                    continue;
                }
                var cas = p_g[0].trim();
                var pack = p_g[1].trim();
                if (!$.isCas(cas)) {
                    msg.push("第" + (i + 1) + "行产品填写不正确");
                    msg_ele.push("batch_content");
                    continue;
                }
                var pack_reg = /^[0-9]+[.]{0,}[0-9]{0,}(G|KG|MG|ML|L|T|MT|U)$/i;
                if (!pack_reg.test(pack)) {
                    msg.push("第" + (i + 1) + "行产品填写不正确");
                    msg_ele.push("batch_content");
                    continue;
                }
            }
        }
        if (cityId == inquiryConst.invalid) {
            success = false;
            msg.push("请选择地址，以便得到最好的报价");
            msg_ele.push("city");
        }
        //if (!invoiceType || invoiceType == -1) {
        //    success = false;
        //    msg.push("请选择发票类型");
        //    msg_ele.push("invoiceType");
        //}

        var customized = $('[name="customized"]').prop("checked");
        var deliveryDay = $('[name="deliveryDay"]:checked').val() || 0;
        if (customized) {
            if (deliveryDay <= 0) {
                success = false;
                msg.push("请选择地址，以便得到最好的报价");
                msg_ele.push("deliveryDay");
            }
        }



        if (note) {
            if (note.length > 60) {
                success = false;
                msg.push("备注最多60个字符");
                msg_ele.push("remark");
            }
        }
        if (!success) {
            $("#err").html(msg.join('<br />')).show();
            return;
        }
        else {
            var cookieUserName = getCookie("userName") || getCookie("_userName") || "";
            if (cookieUserName != "") {//已登录
            }
            else {//未登录，跳转登录
                var arrInquiry, regInquiry = new RegExp("(^| )" + "InquiryStr" + "=([^;]*)(;|$)");
                var cookieInquiry = "";
                if (arrInquiry = document.cookie.match(regInquiry)) {
                    cookieInquiry = unescape(arrInquiry[2]);
                }
                var InquiryModelBatch = { Content: text, CityId: cityId, invoiceType: 6, note: note, source: source };
                if (cookieInquiry != "") {
                    delCookie('InquiryStr');
                    setCookie('InquiryStr', JSON.stringify(InquiryModelBatch));
                    window.location.href = "/UserManager/Login.aspx?ReturnUrl=" + encodeURIComponent(window.location.href) + "&type=2";
                }
                else {
                    setCookie('InquiryStr', JSON.stringify(InquiryModelBatch));
                    window.location.href = "/UserManager/Login.aspx?ReturnUrl=" + encodeURIComponent(window.location.href) + "&type=2";
                }
            }
        }
        $("#err").html('').hide();
        _this.val("正在提交");
        _this.prop("disabled", true);
        $.ajax({
            url: "/PurchaseHelper/Purchase/DelegateInquiry_Batch",
            type: "post",
            data: { Content: text, CityId: cityId, invoiceType: 6, note: note, source: source, customized: customized, deliveryDay: deliveryDay },
            dataType: "text",
            success: function (data) {
                _this.prop("disabled", false);
                _this.val("批量提交");
                if (data == "success") {
                    //$.alert("询价成功!可前去询价管理中查看您的询单", "success");
                    window.location.href = "/Purchasehelper/Purchase/WaitQuote";
                    //$("#err").html('提交成功').show();
                } else {
                    $("#err").html(data).show();
                }
            }
        })
    });
    if ($('[name="it_cas"]').val()) {
        GetIsLowBoilingPointProduct($('[name="it_cas"]').val());
    } else if ($('[name="it_productname"]').val()) {
        GetIsLowBoilingPointProduct($('[name="it_productname"]').val());
    }
    $('[name="it_cas"],[name="it_productname"]').change(function () {
        var val = $(this).val();
        if (!val) {
            return;
        }
        GetIsLowBoilingPointProduct(val);
    });
})

var PurityBind = function (cas) {
    if (cas) {
        $.ajax({
            url: "/PurchaseHelper/Purchase/GetPurityHandler?cas=" + cas,
            type: "get",
            dataType: "json",
            success: function (data) {
                if (data && data.spec.length > 0) {
                    var jsonData = [];
                    for (var i = 0; i < data.spec.length; i++) {
                        if (data.spec[i].name) {
                            jsonData.push({ id: data.spec[i].id, name: data.spec[i].name });
                        }
                    }
                    var $it_purity = $("[name='it_purity']");

                    $it_purity.select3(jsonData);
                }
            }
        })
    } else {
        var $it_purity = $("[name='it_purity']");

        $it_purity.select3([]);
    }
}
function GetIsLowBoilingPointProduct(val) {
    $.ajax({
        url: "/PurchaseHelper/Tools/GetIsLowBoilingPoint",
        type: "post",
        data: { val: val },
        dataType: "json",
        success: function (res) {
            if (res.code == 0 && res.dataObj > 0) {
                $('[data-lowboiling="true"]').show();
            } else {
                $('[data-lowboiling="true"]').hide();
            }
        }
    });
}