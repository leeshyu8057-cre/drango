﻿var argument;
var inquiryUrl = "GlobalDelegateInquiryToSupplier";
var autoRegister = false;
var inquirylistid = 0;
var username;
var islogin = false;
var isSigIn = false;
var validate = false;
$(function () {
    $("input[data-field='email']").blur(function () {
        var username = $(this).val();
        if (username != "") {
            CheckUserName(username);
        }
    })
    $(".close").click(function () {
        $(".Client_bg").css("position", "initial");
        $(".Client_w").hide();
    })
    $(".loga").click(function () {
        $(".fastw").hide();
        $(".falog").hide();
        $(".loinp").val("");
    })
    var msgStr = $("#msg").val();
    if (msgStr != undefined && msgStr != '' && msgStr != "success" && msgStr != "error") {
        $.alert(msgStr);
    }
    $("#ipt_login").click(function () {
        var userName = $("#userName").val();
        var passWord = $("#password").val();
        $("#errmsg").hide();
        if (!userName) {
            //$("#errmsg").text("Username can not be empty").show();
            $("#errmsg").html("<i class=\"mark\">!</i>Username can not be empty").show();
            return;
        } else {
            if (userName.length > 80) {
                //$("#errmsg").text("User name can only enter up to 80 characters").show();
                $("#errmsg").html("<i class=\"mark\">!</i>User name can only enter up to 80 characters").show();
                return;
            } else {

            }
        }
        if (!passWord) {
            //$("#errmsg").text("password can not be blank").show();
            $("#errmsg").html("<i class=\"mark\">!</i>password can not be blank").show();
            return;
        } else {
            if (passWord.length > 80) {
                //$("#errmsg").text("Password can only enter up to 80 characters").show();
                $("#errmsg").html("<i class=\"mark\">!</i>Password can only enter up to 80 characters").show();
                return;
            } else {

            }
        }
        $(this).prop("disabled", true);
        $("#ipt_login").val('logging in…');
        $.ajax({
            url: "/Account/SignEn",
            type: "post",
            async: false,
            cache: false,
            data: { UserName: userName, PassWord: passWord },
            dataType: "json",
            success: function (data) {
                if (data.code == 0) {
                    var url = $.Url();
                    islogin = true;
                    Saveinquiry(1)
                    $(".close").click();
                    $("#islogin").val(data.code);
                    isSigIn = true;

                } else {
                    //$("#errmsg").text(data.msg).show();
                    $(".lop").show();
                }
            },
            complete: function () {
                $("#ipt_login").prop("disabled", false);
                $("#ipt_login").val('Login');
            }
        });
    });
    $("#ipt_register").click(function () {
        Saveinquiry(0)
    })
    isSigIn = $("#islogin").val();
    //Submit an inquiry
    $("input[data-submit='true']").click(function () {

        var productname = $("#productname").val();
        if ($.trim(productname) == "") {
            $("#productname").addClass("error");
            //showErrorMessage("Please input product name."); 
            $("#p_errmsg").text("Please input product name.").show();
            return;
        }
        else {
            $("#productname").removeClass("error");
        }
        //Cas number verification
        var cas = $("#cas").val();
        if ($.trim(cas) != "") {
            if (!isCas(cas)) {
                $("#cas").addClass("error");
                //showErrorMessage("Invalid CAS number.");
                $("#p_errmsg").text("Invalid CAS number.").show();
                return;
            }
            else {
                $("#cas").removeClass("error");
            }
        }
        //Quantity verification
        var amount = $("#amount").val();
        if ($.trim(amount) == "") {
            $("#amount").addClass("error");
            //showErrorMessage("Please input amount.");
            $("#p_errmsg").text("Please input amount.").show();
            return;
        }
        else {
            $("#amount").removeClass("error");
        }

        if (isNaN(amount)) {
            $("#amount").addClass("error");
            //showErrorMessage("Amount can only be numbers.");
            $("#p_errmsg").text("Amount can only be numbers.").show();
            return;
        }
        else {
            $("#amount").removeClass("error");
        }
        var country = $("#country").attr("data-id")
        if ($.trim(country) == "" || $.trim(country) == null) {
            $("#country").addClass("error");
            //showErrorMessage("Please input product name."); 
            $("#p_errmsg").text("Please select region.").show();
            return;
        }
        else {
            $("#country").removeClass("error");
        }

        //Remarks information verification
        var describtion = $("#remark").val();
        if ($.trim(describtion) == "") {
            $("#remark").addClass("error");
            //showErrorMessage("Please input describtion.");
            $("#p_errmsg").text("Please input describtion.").show();
            return;
        }
        else if (describtion.length < 20) {
            $("#remark").addClass("error");
            $("#p_msg").show();
            return;
        }
        else {
            $("#remark").removeClass("error");
        }

        if (isSigIn == "False") {
            //$(".Client_bg").css("position", "fixed");
            //$(".Client_w").show();
            $(".fastw").show();
            $("#register").show();
        } else {
            Saveinquiry(1);
        }

    });


    //Automatically fill in the cas number product name
    var paracas = null;
    var paraname = null;
    var cookieName = getQry("datastr");
    var strCookieVal = getCookie(cookieName);
    if (strCookieVal != null && strCookieVal != undefined) {
        var strDataObj = JSON.parse(strCookieVal);
        $("#productname").val(strDataObj.productname);
        $("#cas").val(strDataObj.cas);
        $("#amount").val(strDataObj.amount);
        $("#unit").val(strDataObj.unit);
        $("#country").val(strDataObj.country);
        $("#remark").val(strDataObj.describtion);
        $("#Name").val(strDataObj.Name);
        $("#Email").val(strDataObj.Email);
    }
    else {
        paracas = getQry("cas");
        paraname = getQry("productName");

        if (paracas != null) {
            if (paracas != "undefined") {
                $("#cas").val(paracas);
            }
        }
        if (paraname != null) {
            if (decodeURI(paraname)) {
                if (decodeURI(paraname) != "undefined") {
                    $("#productname").val(decodeURI(paraname));
                }
            }
        }
    }

    $("a[data-field='moresupplier']").click(function () {
        $("li[data-field='hide']").toggle();
    });

    $("input[data-field='cbsid']").click(function () {
        var chooseCount = $("input[data-field='cbsid']:checked").length;
        $("span[data-field='choosecount']").text(chooseCount);
    });
})
function CheckUserName(username) {
    validate = true;
    $.ajaxSettings.async = false;
    $.get("/Account/TestEmail", { username: $("#Email").val() }, function (result) {
        if (result) {
            $(".lots").hide();
        }
        else {
            validate = false;
            $(".lots").show();
        }
    }, "json");

    $.ajaxSettings.async = true;
    return validate;
}
function Saveinquiry(key) {
    ResetModal();
    var supplier = $("input[data-field='cbsid']:checked");
    if (supplier.length == 0) {
        inquiryUrl = "GlobalDelegateInquiry";
    }

    var cbsid = [];
    for (var i = 0; i < supplier.length; i++) {
        cbsid.push($(supplier[i]).attr("data-cbsid"));
    }
    var is_recommendsuppliers = 0;
    var is_recommend = $("#ck_recommend:checked");
    if (is_recommend.length > 0) {
        is_recommendsuppliers = 1;
    }

    //Product name verification
    var productname = $("#productname").val();
    if ($.trim(productname) == "") {
        $("#productname").addClass("error");
        showErrorMessage("Please input product name.");
        return;
    }
    else {
        $("#productname").removeClass("error");
    }
    //Cas number verification
    var cas = $("#cas").val();
    if ($.trim(cas) != "") {
        if (!isCas(cas)) {
            $("#cas").addClass("error");
            showErrorMessage("Invalid CAS number.");
            return;
        }
        else {
            $("#cas").removeClass("error");
        }
    }

    //Quantity verification
    var amount = $("#amount").val();
    if ($.trim(amount) == "") {
        $("#amount").addClass("error");
        showErrorMessage("Please input amount.");
        return;
    }
    else {
        $("#amount").removeClass("error");
    }

    if (isNaN(amount)) {
        $("#amount").addClass("error");
        showErrorMessage("Amount can only be numbers.");
        return;
    }
    else {
        $("#amount").removeClass("error");
    }

    var country = $("#country").attr("data-id")
    if ($.trim(country) == "" || $.trim(country) == null) {
        $("#country").addClass("error"); 
        showErrorMessage("Please select region.");
        return;
    }
    else {
        $("#country").removeClass("error");
    }

    //Remarks information verification
    var describtion = $("#remark").val();
    if ($.trim(describtion) == "") {
        $("#remark").addClass("error");
        showErrorMessage("Please input describtion.");
        return;
    }
    else if (describtion.length < 20) {
        $("#remark").addClass("error");
        $("#p_msg").show();
        return;
    }
    else {
        $("#remark").removeClass("error");
    }

    if ($("p[data-field='errormsg']").length > 0) {
        return;
    }

    var email = $("#Email").val();
    if (!email && key == 0) {
        $("#Email").addClass("error");
        //showErrorMessage("Please input Email.");
        //$("#register_errmsg").text("Please input Email.").show();
        $("#register_errmsg").html("<i class=\"mark\">!</i>Please input Email.").show();
        return;
    }
    else {
        if (key == 0) {
            var regex = /^[a-zA-Z0-9.!#$%&'*+\/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
            if (!regex.test(email)) {
                $("#Email").addClass("error");
                //showErrorMessage("Incorrect mailbox format!");
                //$("#register_errmsg").text("Incorrect mailbox format!").show();
                $("#register_errmsg").html("<i class=\"mark\">!</i>Incorrect mailbox format!").show();
                return;
            }
        }
    }
    if (email.trim() != "" && isSigIn == "False") {
        validate = CheckUserName(email.trim());
        if (!validate) {
            $("#register_errmsg").html("<i class=\"mark\">!</i>The mailbox has already been registered.").show();
            return;
        }
    }

    var name = $("#Name").val();
    if (!name && key == 0) {
        $("#Name").addClass("error");
        //showErrorMessage("Please input Name.");
        //$("#register_errmsg").text("Please input Name.").show();
        $("#register_errmsg").html("<i class=\"mark\">!</i>Please input Name.").show();
        return;
    }
    var mobile = $("#Mobile").val();
    if (!mobile && key == 0) {
        $("#Mobile").addClass("error");
        //showErrorMessage("Please input Mobile.");
        //$("#register_errmsg").text("Please input Mobile.").show();
        $("#register_errmsg").html("<i class=\"mark\">!</i>Please input Mobile.").show();
        return;
    }
    else {
        if (key == 0) {
            var isMob = /^[0-9][0-9]+$/;
            if (isMob.test(mobile)) {
                $("#Mobile").removeClass("error");
            }
            else {
                $("#Mobile").addClass("error");
                $("#register_errmsg").html("<i class=\"mark\">!</i>Mobile phone format is incorrect.").show();
                return;
            }
        }
    }
    //else {
    //    //var mobileReg = /^\d{8,20}$/;
    //    var phoneReg = /^((\+?86)|(\(\+86\)))?1\d{10}$/;
    //    if (!phoneReg.test(mobile)) {
    //        $("#Mobile").addClass("error");
    //        showErrorMessage("please enter the correct phone number");
    //        return;
    //    }
    //}
    var flag = true;
    if (key == 0) { 
        $.ajax({
            url: "/Account/ContactRegister",
            async: false,
            type: "post",
            dataType:"json",
            data: { email: email, contact: name, phone: mobile }, 
            success: function (data) { 
                if (data.code <= 0) {
                    alert(data.msg);
                    flag = false;
                    return;
                }
                else {
                    //alert("注册成功!");
                    $(".close").click();
                    $("#islogin").val(data.code);
                    isSigIn = true;
                }
            }
        }) 
    }
    if (!flag) {
        return;
    }

    var unit = $("#unit").val();
    var unitname = $("#unit option:selected").text();
    var country = $("#country").attr("data-id");//$("#country").val();
    var inquirysource = getQry("source");
    var cbnumber = getQry("cbnumber");
    //if (cbnumber == null) {
    //    showErrorMessage("Invalid cbnumber!");
    //    return;
    //}
    var countrytext = $("#country").text().trim();//$("#country option:selected").text();


    var packages = new Array();
    var requireds = new Array();
    $.each($(".amount"), function () {
        var amount = $(this).val();
        if (amount != "" && amount != "0") {
            var unitid = $(this).closest("li").find("[name='unit'] :selected").val();
            var unitname = $(this).closest("li").find("[name='unit'] :selected").text();
            packages.push({ Amount: amount, UnitId: unitid, UnitName: unitname });
            //requireds.push({ Number: amount, Unit: { Id: unitid, Name: unitname } });
            requireds.push({ Number: amount, Unit: unitid });
        }
    })


    var Source;
    if (country == 4) {
        Source = "ProductListHWToGN_CN_M";
    }
    else {
        Source = "ProductListHWToGN_EN_M";
    }

    argument =
    {
        cbsid: cbsid.join(","),
        productname: productname,
        cas: cas,
        cbnumber: cbnumber,
        number: amount + unitname,
        unit: unit,
        port: 1,
        portdescribe: "",
        country: country,
        describtion: describtion,
        attachmentpath: "",
        inquirysource: inquirysource,
        countrytext: countrytext,
        amount: amount,
        packages: packages,
        requireds: requireds,
        Name: name,
        Email: email,
        Mobile: mobile,
        source: Source,
        is_recommendsuppliers: is_recommendsuppliers,
        uniquecode: localStorage.getItem("UserAgent")
    };


    var cookieUserName = getCookie("userName") || getCookie("_userName") || "";
    inquirySave(argument);

    //toJson = function () {
    //    return { InquiryOperator: username, OtherPlatOrderNumber: inquirylistid, ProductName: productname, NationalityID: country, Nationality: countrytext, Cas: cas, PurityId: 0, Purity: "", Items: requireds, CityId: 133, Remark: describtion, PublishContact: false, UISource: Source, InvoiceTypeId: 3 }
    //}
    //if (inquirylistid != 0) {
    //    $.ajax({
    //        url: "/PurchaseHelper/Purchase/AddInquiry",
    //        async: false,
    //        type: "post",
    //        data: { inquiryStr: JSON.stringify(toJson()) },
    //        dataType: "json",
    //        success: function (json) {
    //            if (json.code == 0) {
    //                if (country != 4) {
    //                    $("#mainbox").hide();
    //                    $("#success").show();
    //                    $("#successkefu").show();
    //                }
    //            } else {
    //                alert(json.msg);
    //            }
    //        }
    //    });
    //}

    return;
    if (cookieUserName != '') {
        inquirySave(argument);
    }
    else {//跳登录页面
        //页面信息保存在cookie中           
        var timestamp = new Date().getTime();
        setCookie("datastr" + timestamp, JSON.stringify(argument), "d1");
        var getReturnUrl = decodeURIComponent($("#returnUrl").val());
        if (getReturnUrl != undefined && getReturnUrl != '' && getReturnUrl.split('&').length > 0) {
            var returnUrlStr = "";
            for (var i = 0; i < getReturnUrl.split('&').length; i++) {
                if (getReturnUrl.split('&')[i].indexOf("msg") < 0 && getReturnUrl.split('&')[i].indexOf("datastr") < 0) {
                    returnUrlStr += getReturnUrl.split('&')[i] + "&";
                }
            }
            returnUrlStr = encodeURIComponent(returnUrlStr.substr(0, returnUrlStr.length - 1));
        }
        if (returnUrlStr.indexOf("&") > 0) {
            window.location.href = '/Login_en.aspx?ReturnUrl=' + returnUrlStr + encodeURIComponent("&datastr=datastr" + timestamp);
        }
        else {
            window.location.href = '/Login_en.aspx?ReturnUrl=' + returnUrlStr + encodeURIComponent("?id=1&datastr=datastr" + timestamp);
        }
    }
}

function inquirySave(argument) {
    $.ajax({
        url: "/PurchaseHelper/Purchase/" + inquiryUrl,
        async: false,
        type: "Post",
        data: { str: JSON.stringify(argument) },
        dataType: "text",
        success: function (data) {
            var dataobj = $.parseJSON(data);
            if (dataobj.msg == "success") {
                inquirylistid = dataobj.dataObj.InquiryListID;
                username = dataobj.dataObj.InquiryUserName;
                $("#mainbox").hide();
                $("#success").show();
                //$("#successkefu").show();
            }
            else {
                if (dataobj.code == -3) {
                    inquirylistid = dataobj.dataObj.InquiryListID;
                    username = dataobj.dataObj.InquiryUserName;
                    $("#mainbox").hide();
                    $("#div_danger").show();
                    //$("#successkefu").show();
                }
                else if (dataobj.code == -4) {
                    $("#p_errmsg").text("According to relevant laws, regulations and policies, this product is prohibited from sale!").show();
                }
                else {
                    alert(dataobj.msg);
                }
            }
        }
    })
}

function showErrorMessage(msg) {
    $("input[data-submit='true']").after('<p id="err" class="red" style="" data-field="errormsg">' + msg + '</p>');
}

function ResetModal() {
    $("li[data-field='errormsg']").remove();
    $("p[data-field='errormsg']").remove();
}

function getCookie(name) {
    var arr, reg = new RegExp("(^| )" + name + "=([^;]*)(;|$)");
    if (arr = document.cookie.match(reg))
        return unescape(arr[2]);
    else
        return null;
}

function getQry(name) {//Get page pass parameters
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
    var r = window.location.search.substr(1).match(reg);
    if (r != null) return (r[2]); return null;
}

function isCas(str) {
    if (str) {
        var patter = /^(?:[0-9]{5,12}|[0-9]{2,9}-[0-9]{2}-[0-9])$/
        return patter.test(str);
    }
    return false;
}

function setCookie(name, value, time) {
    var strsec = getsec(time);
    var exp = new Date();
    exp.setTime(exp.getTime() + strsec * 1);
    document.cookie = name + "=" + escape(value) + ";expires=" + exp.toGMTString() + "; path=/";
}
function getsec(str) {
    var str1 = str.substring(1, str.length) * 1;
    var str2 = str.substring(0, 1);
    if (str2 == "s") {
        return str1 * 1000;
    }
    else if (str2 == "h") {
        return str1 * 60 * 60 * 1000;
    }
    else if (str2 == "d") {
        return str1 * 24 * 60 * 60 * 1000;
    }
}