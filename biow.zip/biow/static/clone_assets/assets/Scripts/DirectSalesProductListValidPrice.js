﻿$(function () {
    //var src = $("[src*='/signalr/hubs']").attr("src");
    //var host = src.substring(0, src.indexOf("/signalr/hubs"));
    //$.connection.hub.url = host + "/signalr";
    if (!$.connection.hub.qs) {
        $.connection.hub.qs = {};
    }
    if ($("#isWechat").length > 0) {
        $.connection.hub.qs.plat = $("#isWechat").val().toLowerCase() == "true" ? "4" : "2";
    } else {
        if (window.navigator && window.navigator.userAgent) {
            $.connection.hub.qs.plat = window.navigator.userAgent.toLowerCase().match(/MicroMessenger/i) == "micromessenger" ? "4" : "2";
        }

    }

    var hub = $.connection.reagentOrderValidPriceHub;
    hub.client.ReagentOrderValidPriceComplete = function (res) {
        if (res.code == 0) {
            if (res.data && res.data.length > 0) {
                var ids = [];
                for (var i = 0; i < res.data.length; i++) {
                    var row = res.data[i];
                    ids.push(row["ID"]);
                }
                hub.server.notifyConfirm(ids);
                var html = '<p>购物车产品有价格变动,请注意查看</p>';
                var title = '<div style="text-align: left;font-size: 17px;font-weight: 400;"><div style="background: red;display: inline-block;width: 15px;height: 15px;border-radius: 15px;text-align: center;color: #fff;padding: 0;margin-right: 10px;font-size: 12px;line-height: 15px;">!</div>价格变动提醒</div>';
                $.confirm2({
                    title: title,
                    msg: html,
                    cancelText: "确定",
                    sureText: "查看详情",
                    sureHandler: function () {
                        window.location.href = "/PurchaseHelper/Purchase/AlreadyQuote";
                        $.WebUI.closedialog();
                    }
                });
            }
        }
    };
    $.connection.hub.start().done(function () {
        var userName = getCookie("userName") || getCookie("_userName");
        if (userName) {
            hub.server.getReagentPriceChangeInfo();
        }
    });
})