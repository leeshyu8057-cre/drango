﻿/*
 * 功能：产品Cas号判断规则，以及转换
 * 时间：2016-3-8
 * 作者：李建峰
 */
$.extend({
    /*
     * 功能：是Cas号
     */
    isCas: function (str) {
        if (str) {
            var patter = /^(?:[0-9]{5,12}|[0-9]{2,9}-[0-9]{2}-[0-9])$/
            return patter.test(str);
        }
        return false;
    },
    convertToCas: function (str) {
        if ($.isCas(str)) {
            var patter = /^[0-9]{5,12}$/;
            if (patter.test(str)) {
                var len = str.length;
                var last = str.substring(len - 1, len);
                var middle = str.substring(len - 3, len - 1);
                var first = str.substring(0, len - 3);
                return first + "-" + middle + "-" + last;
            }
            return str;
        }
        return null;
    },
    nullString: function (str) {
        if (!str) {
            return "无";
        }
        return str;
    }
});