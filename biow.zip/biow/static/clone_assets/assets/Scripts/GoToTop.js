﻿/*
 * 功能：回到页面顶部
 * 时间：2015-1-28
 * 作者：李建峰
 */
$(document).ready(function () {
    //滚动条事件
    $(window).scroll(function () {
        var $top = $("a[href='#top']");
        if ($(window).scrollTop() > 0) {
            $top.show();
        }
        else {
            $top.hide();
        }
    });
    //显示菜单
    $("#icon_menu").click(function () {
        var $icon_menu = $(this).find("div");
        if ($icon_menu.hasClass("icon_menu")) {
            $("#right_menu_box").attr("class", "right_menu_box1").focus();
            $icon_menu.attr("class", "icon_menu_c");
        }
        else
        {
            $("#right_menu_box").attr("class", "right_menu_box");
            $icon_menu.attr("class", "icon_menu");
        }
    });
    //关闭菜单
    $("[data-close='true']").click(function () {
        $("#right_menu_box").attr("class", "right_menu_box");
        var $icon_menu = $("#icon_menu>div");
        $icon_menu.attr("class", "icon_menu");
    });
    $(".right_menu").mouseleave(function () {
        $("#right_menu_box").attr("class", "right_menu_box");
        var $icon_menu = $("#icon_menu>div");
        $icon_menu.attr("class", "icon_menu");
    });

})