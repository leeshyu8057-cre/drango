2.2 bioweb/setclone13.py（批次克隆入口）
你一開始指定的路徑是：bioweb/setclone13.py 用來爬取儲存。 合理設計是：
* setclone13.py 不直接寫爬蟲細節，只：
    * 讀取一份 URL 列表（如 urls.txt 或 DB）
    * 使用 from chem_site.bioweb.products.scraper import scrape_product
    * 把結果寫入資料庫（Product / Category 等 Model）
    * 在 terminal 中提供互動式體驗（例如輸入單一 URL 立即顯示結果）
這樣：
* CLI 批次救援／修復用 setclone13.py
* 核心爬蟲維護集中在 scraper.py → 下次不會一改就動到四個地方。

三、Django Admin 後台擴充紀錄
這一段就是你說的：
「在 Django admin 後台登入頁加入管理及新增商品名功能，再加一個很重要的『導入商品數據』功能。」
我們把它拆成 2 層：
1. 單一 URL 同步產品（從 ChemicalBook URL 直接建立 / 更新）
2. 通用導入格式（CSV / 爬蟲輸出） → 這個是你新加的要求，下面會設計規格
3.1 products/admin.py 擴充內容
目前紀錄應包含以下幾項概念：
* ProductAdmin 中：
    * 新增 ProductSyncForm
        * 欄位：
            * url（必填，ChemicalBook 商品頁 URL）
            * sku（選填）
            * category（選填，或用文字自動建立）
    * 新增一個後台 view：sync_product_from_url：
        * 只有 staff / superuser 可使用
        * 表單送出後：
            * 呼叫 scraper.scrape_product(url)
            * 比對 DB 中是否已有同一個 SKU / CAS / URL
            * 決定是 create 還是 update
        * 使用 messages.success / error 顯示結果
* 在 change list 頁面加入按鈕：
    * 使用 ProductAdmin.get_urls() 加一條自定義路徑（例：/admin/products/product/sync/）
    * 對應模板：templates/admin/products/sync.html
    * 在 change_list template 中，用按鈕連到上述 URL （此處你先記錄結構，不一定已經客製 admin base template）
完成紀錄存檔
3.2 README.md 第 8 節（操作說明）
這一段是救援的核心：
* 說明：
    * 如何在 Django admin 後台使用「🤖 三項爬蟲同步選擇減輕網站優化按鈕,及測試皆能順暢同步並且直接同步鏡像“https://chemicalbook.com”首頁,即等等頁面,及完成比“https://chemicalbook.com”更順暢但又鏡像的網頁顏色等等都鏡像網頁完成需求css AOS ,js
    * 表單各欄位的說明（URL / SKU / Category）
    * 同步成功／失敗時會看到什麼訊習 完全後台紀錄同步流程及監控存檔紀錄
* 指出：
    * 欄位對應關係（產品名稱 → Product.name、CAS → Product.cas_no…）
    * 可以接 CSV 匯入、定時同步、管理命令等

3.3 新依賴：beautifulsoup4,urllib,tls,
紀錄應包含：
* 在 requirements.txt 新增：
    * beautifulsoup4
* 若有使用 lxml 或 html5lib，也一併標記（視你的環境而定）

四、你新加的「通用導入格式」設計（第二次救援後的 進階補強）
接下來是你這句的核心需求：
再加入一個很重要的功能： 有導入商品數據的功能，以常用爬蟲數據能通用導入格式，爬取對應的產品欄位及首頁佈局圖片名等等。
4.1 通用匯入格式（建議用 CSV）
建議在 README 的「第 8 節」補充一個 標準 CSV schema：
name,sku,cas_no,purity,min_order_qty,supply_ability,category,description,image_url,source_url,updated_at
Lutein powder 5%-80%,LTN-001,1234-56-7,80%,25kg,10 tons/month,Carotenoids,"長描述文字...",https://...,https://...,2025-11-13
這樣你有幾個好處：
* 不管是用 scraper.py、Selenium、或之後改用 Playwright， 只要最後輸出這種 CSV，就可以丟進導入功能。
* 若未來不是 ChemicalBook，而是別的化工網站，也只要做 mapping 產生同格式 CSV。
4.2 導入流程設計（Admin / CLI 通用）


    * 新增一個「匯入商品（CSV）」的後台頁面
* Template
    * templates/admin/products/import.html
Admin 端流程：
1. 後台左側「Products」 → 上方新增按鈕「📥 匯入商品（CSV）」。
2. 上傳一個 CSV 檔案（符合上述 header）。
3. 後端逐列 parse：
    * 先用 sku 或 cas_no 做唯一識別（避免重複）
    * 存 / 更新 Product 與 Category
    * image_url 可先存在欄位中，之後由 background task 把圖片下載到本機 / object storage。
4. 匯入完成顯示：
    * 成功新增：X 筆
    * 成功更新：Y 筆
    * 錯誤：Z 筆（可 download log）
這樣你就有 「單一 URL 同步」 ＋ 「批次 CSV 導入」 兩種救援模式。

五、首頁 & 商品頁 RWD 佈局（鏡像 ChemicalBook 手機 + 桌面）
你提到：
鏡像所有 https://m.chemicalbook.com 手機頁面首頁商品頁 及 https://m.chemicalbook.com/ProductDetail_EN_magnesium-sulfate-heptahydrate_2887425.htm 以及 https://chemicalbook.com/ 桌面頁 完成響應 RWD 網頁增加流暢度。
紀錄上可以這樣寫（給之後第三步實作用）：
5.1 bioweb/templates/base.html
* 共用區塊：
    * Header：Logo + 搜尋框（化學品名稱 / CAS / SKU）
    * 導覽列：分類（Category）、關於我們、聯絡…
    * Footer：聯絡資訊、版權、語系切換（預留）
* RWD 原則：
    * 使用 CSS grid 或 flex，配合 media queries
    * 手機版：
        * Header 縮成一列，Logo + 搜尋 + 菜單 icon
    * 桌面版：
        * 左 Logo，中間搜尋列，右側登入 / 語系
5.2 手機首頁：bioweb/templates/home.html
模仿 m.chemicalbook.com 的風格，設計以下區塊：
* Hero 搜尋區塊：
    * 大搜尋框：placeholder：「Product Name / CAS / Supplier」
* 熱門分類（cards）：
    * 例如：Vitamins & Nutraceuticals、Inorganic Salts、Solvents…
    * 每個 card 使用 Category 列表生成
* 精選商品列表：
    * 直接從 DB 抓 Product，顯示：
        * 缩圖（image_url）
        * 名稱
        * CAS
        * 一小段描述
    * 手機版一列 1 卡片，桌面一列 3–4 卡片
5.3 商品頁：products/templates/products/detail.html
模仿：
* 左側：商品圖片（RWD 下可改上方）
* 右側：
    * 商品名稱
    * CAS
    * SKU
    * 純度、最小訂購量、供應能力
* 下方：
    * 詳細描述（HTML / 富文本）
    * 更新日期
    * 可能的相關產品（同分類）
這個模板會吃你前面爬回來的欄位，所以「爬蟲 / 匯入格式 → DB → 模板」這條鏈就打通了。

六、小結：這次「第二次救援」你可以這樣標記
你可以把今天這份當成正式紀錄（例如貼進 Notion / README / 專案日誌）：
第二次救援補救紀錄（@2🚀）
* 專案檔案邏輯已完全救援：爬蟲核心、CLI、Admin 後台、README、依賴套件。
* 新增 chem_site/bioweb/products/scraper.py 作為爬蟲核心。
* bioweb/setclone13.py 作為批次克隆入口，呼叫 scraper。
* products/admin.py 擴充 ProductAdmin：
    * 單一 URL 同步（ChemicalBook → Product / Category）
    * Admin change list 頁面的「🤖 爬蟲同步」按鈕與 sync.html 表單。
* README.md 第 8 節：說明後台匯入與自動爬蟲流程。
* 安裝 beautifulsoup4，供 HTML 解析使用。
* 設計通用 CSV 匯入格式，預備加入「商品數據導入」功能，對應爬蟲輸出。
* 規劃首頁與商品頁的 RWD 結構，目標鏡像 ChemicalBook 手機與桌面頁的使用體驗。
等你第三步要「實際改 code、一檔一檔對」的時候，就可以直接以這份紀錄當 checklist 去核對哪個檔案已經照這個設計完成、哪個還沒補上。這樣就算再流失一次，邏輯和規格也還在。