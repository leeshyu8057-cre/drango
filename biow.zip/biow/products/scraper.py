"""
Utility functions to fetch and parse product data from ChemicalBook pages.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import datetime
from typing import Dict, Optional

from bs4 import BeautifulSoup
from products.fetchers import FetchResult, requests_fetcher, curl_cffi_fetcher, selenium_fetcher

HEADERS = {
    'User-Agent': (
        'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) '
        'AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36'
    )
}


class ScrapeError(Exception):
    """Raised when remote data cannot be parsed."""


@dataclass
class ProductPayload:
    raw: Dict[str, str]

    def normalized(self) -> Dict[str, str]:
        data = {}
        for key, value in self.raw.items():
            if value is None:
                continue
            data[key] = value.strip()
        return data


def _extract_with_labels(pairs, aliases):
    for label, value in pairs:
        label_clean = label.lower()
        for alias in aliases:
            if alias in label_clean:
                return value
    return None


def to_mobile_url(url: str) -> str:
    if 'chemicalbook' not in url:
        return url
    if '://m.' in url:
        return url
    return url.replace('://www.', '://m.').replace('://chemicalbook', '://m.chemicalbook')


FETCHER_MAP = {
    'requests': requests_fetcher,
    'curl_cffi': curl_cffi_fetcher,
    'selenium': selenium_fetcher,
}


def fetch_chemicalbook_product(url: str, mode: str = 'requests', **fetch_kwargs) -> Dict[str, Optional[str]]:
    mobile_url = to_mobile_url(url)
    fetcher = FETCHER_MAP.get(mode, requests_fetcher)
    try:
        result: FetchResult = fetcher(mobile_url, headers=HEADERS, **fetch_kwargs)
    except Exception as exc:
        raise ScrapeError(f'Fetch failed for {mobile_url}: {exc}') from exc

    soup = BeautifulSoup(result.content, 'html.parser')

    name = soup.find('h1')
    product_name = name.get_text(strip=True) if name else None

    supplier = soup.select_one('.supplierName, .company-name, .gold_supplier')
    supplier_name = supplier.get_text(strip=True) if supplier else None

    description_block = soup.select_one('.product-description, .proDetail, #content')
    description = description_block.get_text(separator='\n', strip=True) if description_block else None

    image_tag = soup.select_one('.detailPic img, .main_img img, .product-img img')
    if not image_tag:
        image_tag = soup.find('img')
    external_image = image_tag['src'] if image_tag and image_tag.get('src', '').startswith('http') else None

    pairs = []
    for row in soup.select('table tr'):
        cells = row.find_all(['th', 'td'])
        if len(cells) >= 2:
            pairs.append((cells[0].get_text(strip=True), cells[1].get_text(strip=True)))

    def find_value(*aliases):
        return _extract_with_labels(pairs, aliases)

    cas_number = find_value('cas', 'cas no')
    purity = find_value('purity')
    package = find_value('package')
    min_order = find_value('min', 'order')
    supply_ability = find_value('supply ability', 'supply')
    update_time = find_value('update', 'release')

    min_order_kg = None
    if min_order:
        match = re.search(r'([\d.]+)', min_order)
        if match:
            min_order_kg = match.group(1)

    parsed_date = None
    if update_time:
        for fmt in ('%Y-%m-%d', '%Y/%m/%d', '%Y.%m.%d'):
            try:
                parsed_date = datetime.strptime(update_time[:10], fmt).date()
                break
            except ValueError:
                continue

    sku_match = re.search(r'_(\d+)\.htm', url)
    sku = sku_match.group(1) if sku_match else (cas_number or product_name)

    payload = ProductPayload(
        raw={
            'name': product_name,
            'sku': sku,
            'cas_number': cas_number,
            'purity': purity,
            'package': package,
            'min_order_kg': min_order_kg,
            'supply_ability': supply_ability,
            'update_time': parsed_date.isoformat() if parsed_date else None,
            'description': description,
            'supplier_name': supplier_name,
            'external_image': external_image,
            'source_url': result.url,
            'fetch_mode': result.mode,
        }
    )
    data = payload.normalized()
    if not data.get('name'):
        raise ScrapeError('Unable to locate product name on the page.')
    return data
