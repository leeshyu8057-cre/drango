from django.test import TestCase
from django.urls import reverse
from .models import Category, Product


class ProductViewsTests(TestCase):
    def setUp(self):
        self.organics = Category.objects.create(name='Organics')
        self.inorganics = Category.objects.create(name='Inorganics')
        self.product = Product.objects.create(
            name='Acetone',
            sku='AC-001',
            category=self.organics,
            price=25.5,
        )
        Product.objects.create(
            name='Sodium Chloride',
            sku='SC-002',
            category=self.inorganics,
        )

    def test_product_list_displays_all_products(self):
        response = self.client.get(reverse('products:list'))
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'products/list.html')
        self.assertContains(response, 'Acetone')
        self.assertContains(response, 'Sodium Chloride')

    def test_product_list_filters_by_category(self):
        response = self.client.get(
            reverse('products:list'),
            {'category': self.organics.id},
        )
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Acetone')
        self.assertNotContains(response, 'Sodium Chloride')

    def test_product_detail_shows_selected_product(self):
        response = self.client.get(reverse('products:detail', args=[self.product.pk]))
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'products/detail.html')
        self.assertEqual(response.context['product'], self.product)
        self.assertContains(response, 'Acetone')
