import csv
import io
from datetime import datetime

from django import forms
from django.contrib import admin, messages
from django.shortcuts import redirect, render
from django.urls import path

from .models import Category, Product, Document, ProductSyncLog
from .scraper import fetch_chemicalbook_product, ScrapeError


@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ('name', 'parent')
    search_fields = ('name',)


class DocumentInline(admin.TabularInline):
    model = Document
    extra = 0


class ProductImportForm(forms.Form):
    file = forms.FileField(
        help_text='支援 UTF-8 CSV，欄位：name, sku, cas_number, formula, purity, package, '
        'min_order_kg, supply_ability, update_time(YYYY-MM-DD), description, supplier_name, '
        'supplier_location, external_image, source_url, category'
    )


class ProductSyncForm(forms.Form):
    url = forms.URLField(label='ChemicalBook 產品頁 URL')
    sku = forms.CharField(required=False, help_text='可自訂 SKU，若留白將自動取自 URL/CAS。')
    category = forms.ModelChoiceField(
        queryset=Category.objects.all(),
        required=False,
        help_text='若留白預設為 General。',
    )
    fetch_mode = forms.ChoiceField(
        choices=[
            ('requests', 'Requests（一般）'),
            ('curl_cffi', 'curl_cffi（Chrome TLS 指紋）'),
            ('selenium', 'Selenium（瀏覽器鏡像—預留）'),
        ],
        required=False,
        initial='requests',
        label='Fetch Mode',
        help_text='遇到 TLS/JA3 防護可改用 curl_cffi；Selenium 目前尚未實作。',
    )


@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ('name', 'sku', 'category', 'supplier_name', 'update_time')
    list_filter = ('category',)
    search_fields = ('name', 'sku', 'cas_number')
    inlines = [DocumentInline]
    change_list_template = 'admin/products/change_list.html'
    fieldsets = (
        ('基本資訊', {
            'fields': (
                'name',
                'sku',
                'category',
                'supplier_name',
                'supplier_location',
                'keywords',
            )
        }),
        ('化學資料', {
            'fields': (
                'formula',
                'cas_number',
                'ec_number',
                'purity',
                'description',
            )
        }),
        ('供應資訊', {
            'fields': (
                'package',
                'min_order_kg',
                'supply_ability',
                'update_time',
                'release_date',
            )
        }),
        ('視覺資料', {
            'fields': ('image', 'external_image', 'source_url', 'fetch_mode')
        }),
    )

    def _log_sync(self, sku, url, mode, status, message=''):
        ProductSyncLog.objects.create(
            sku=sku or '',
            url=url,
            fetch_mode=mode,
            status=status,
            message=message[:500],
        )

    def get_changeform_initial_data(self, request):
        return {
            'name': 'Lutein powder 5%-80%',
            'sku': 'CB-3566778',
            'category': Category.objects.first(),
            'supplier_name': 'Wuhan Mayue Longteng Technology Development Co., Ltd.',
            'supplier_location': 'China',
            'formula': 'C40H56O2',
            'cas_number': '127-40-2',
            'purity': '5%-80%',
            'package': '≥1 Kg',
            'min_order_kg': 0.1,
            'supply_ability': '1000 Kg',
            'update_time': datetime(2025, 11, 12).date(),
            'description': (
                'Lutein is extracted from Marigold with excellent uniformity and stability '
                'for beverage, food coloring, nutrient enrichment, tablets, and hard capsules.'
            ),
            'keywords': 'Color fixative, Food additives',
            'external_image': 'https://images.pexels.com/photos/37347/medicines-cure-tablets-pharmacy.jpg',
        }

    def get_urls(self):
        urls = super().get_urls()
        custom = [
            path(
                'import-data/',
                self.admin_site.admin_view(self.import_products),
                name='products_product_import',
            ),
            path(
                'sync-from-url/',
                self.admin_site.admin_view(self.sync_product_from_url),
                name='products_product_sync',
            ),
        ]
        return custom + urls

    def import_products(self, request):
        if request.method == 'POST':
            form = ProductImportForm(request.POST, request.FILES)
            if form.is_valid():
                file_obj = form.cleaned_data['file']
                data = io.StringIO(file_obj.read().decode('utf-8'))
                reader = csv.DictReader(data)
                created = 0
                updated = 0
                for row in reader:
                    if not row.get('sku'):
                        continue
                    category_name = row.get('category') or 'General'
                    category, _ = Category.objects.get_or_create(name=category_name)
                    defaults = {
                        'name': row.get('name', '').strip(),
                        'category': category,
                        'formula': row.get('formula', ''),
                        'cas_number': row.get('cas_number', ''),
                        'purity': row.get('purity', ''),
                        'package': row.get('package', ''),
                        'supply_ability': row.get('supply_ability', ''),
                        'description': row.get('description', ''),
                        'supplier_name': row.get('supplier_name', ''),
                        'supplier_location': row.get('supplier_location', ''),
                        'external_image': row.get('external_image', ''),
                        'keywords': row.get('keywords', ''),
                        'source_url': row.get('source_url', ''),
                    }
                    if row.get('min_order_kg'):
                        try:
                            defaults['min_order_kg'] = float(row['min_order_kg'])
                        except ValueError:
                            pass
                    if row.get('update_time'):
                        try:
                            defaults['update_time'] = datetime.strptime(
                                row['update_time'], '%Y-%m-%d'
                            ).date()
                        except ValueError:
                            pass
                    product, created_flag = Product.objects.update_or_create(
                        sku=row['sku'],
                        defaults=defaults,
                    )
                    if created_flag:
                        created += 1
                    else:
                        updated += 1

                messages.success(request, f'導入完成：新增 {created} 筆，更新 {updated} 筆。')
                return redirect('..')
        else:
            form = ProductImportForm()
        context = {
            **self.admin_site.each_context(request),
            'opts': self.model._meta,
            'form': form,
        }
        return render(request, 'admin/products/import.html', context)

    def sync_product_from_url(self, request):
        if request.method == 'POST':
            form = ProductSyncForm(request.POST)
            if form.is_valid():
                url = form.cleaned_data['url']
                mode = form.cleaned_data.get('fetch_mode') or 'requests'
                try:
                    data = fetch_chemicalbook_product(url, mode=mode)
                except ScrapeError as exc:
                    self._log_sync(form.cleaned_data.get('sku'), url, mode, 'fail', str(exc))
                    messages.error(request, f'爬蟲失敗：{exc}')
                else:
                    sku = form.cleaned_data.get('sku') or data.get('sku')
                    if not sku:
                        self._log_sync('', url, mode, 'fail', '缺少 SKU')
                        messages.error(request, '無法推斷 SKU，請手動輸入。')
                        return redirect(request.path)
                    category = form.cleaned_data.get('category')
                    if not category:
                        category, _ = Category.objects.get_or_create(name='General')
                    defaults = {
                        'name': data.get('name', sku),
                        'category': category,
                        'cas_number': data.get('cas_number', ''),
                        'purity': data.get('purity', ''),
                        'package': data.get('package', ''),
                        'supply_ability': data.get('supply_ability', ''),
                        'description': data.get('description', ''),
                        'supplier_name': data.get('supplier_name', ''),
                        'external_image': data.get('external_image', ''),
                        'source_url': data.get('source_url', url),
                        'fetch_mode': data.get('fetch_mode', mode),
                    }
                    if data.get('min_order_kg'):
                        try:
                            defaults['min_order_kg'] = float(data['min_order_kg'])
                        except ValueError:
                            pass
                    if data.get('update_time'):
                        try:
                            defaults['update_time'] = datetime.fromisoformat(data['update_time']).date()
                        except ValueError:
                            pass
                    product, created = Product.objects.update_or_create(
                        sku=sku,
                        defaults=defaults,
                    )
                    msg = '已新增' if created else '已更新'
                    messages.success(request, f'{msg}商品：{product.name}')
                    self._log_sync(sku, url, mode, 'success', msg)
                    return redirect('..')
        else:
            form = ProductSyncForm()
        context = {
            **self.admin_site.each_context(request),
            'opts': self.model._meta,
            'form': form,
        }
        return render(request, 'admin/products/sync.html', context)


@admin.register(ProductSyncLog)
class ProductSyncLogAdmin(admin.ModelAdmin):
    list_display = ('created_at', 'sku', 'fetch_mode', 'status', 'url')
    list_filter = ('status', 'fetch_mode')
    search_fields = ('sku', 'url', 'message')
    readonly_fields = ('created_at', 'sku', 'url', 'fetch_mode', 'status', 'message')
