from __future__ import annotations

from typing import List

from django.db.utils import OperationalError, ProgrammingError

from .models import Category, Product


def navigation_categories(request) -> dict[str, object]:
    """
    Provide navbar/home context with categories, featured products, suppliers, and search suggestions.
    Falls back to empty lists when DB tables are unavailable (e.g., during migrations).
    """
    categories: List[Category] = []
    featured_products: List[Product] = []
    featured_suppliers: List[str] = []
    search_suggestions: List[dict] = []

    try:
        categories = list(Category.objects.all().order_by('name'))
        featured_products = list(
            Product.objects.select_related('category')
            .order_by('-update_time', '-id')[:8]
        )
        suggestion_qs = Product.objects.order_by('-update_time', 'name')[:10]
        search_suggestions = [
            {
                'value': product.name,
                'label': product.name,
                'cas': product.cas_number or '',
                'sku': product.sku or '',
            }
            for product in suggestion_qs
        ]
        featured_suppliers = list(
            Product.objects.exclude(supplier_name='')
            .values_list('supplier_name', flat=True)
            .distinct()[:6]
        )
    except (OperationalError, ProgrammingError):
        pass

    return {
        'nav_categories': categories,
        'featured_products': featured_products,
        'featured_suppliers': featured_suppliers,
        'search_suggestions': search_suggestions,
    }
