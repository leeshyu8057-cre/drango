from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import requests
from curl_cffi import requests as curl_requests


@dataclass
class FetchResult:
    content: str
    url: str
    mode: str


def requests_fetcher(url: str, headers: Optional[dict] = None, **kwargs) -> FetchResult:
    resp = requests.get(url, headers=headers, timeout=kwargs.get('timeout', 30))
    resp.raise_for_status()
    return FetchResult(resp.text, resp.url, mode='requests')


def curl_cffi_fetcher(url: str, headers: Optional[dict] = None, **kwargs) -> FetchResult:
    impersonate = kwargs.get('impersonate', 'chrome110')
    resp = curl_requests.get(
        url,
        headers=headers,
        impersonate=impersonate,
        timeout=kwargs.get('timeout', 30),
        proxies=kwargs.get('proxies'),
    )
    resp.raise_for_status()
    return FetchResult(resp.text, resp.url, mode=f'curl_cffi:{impersonate}')


def selenium_fetcher(url: str, **kwargs) -> FetchResult:
    raise RuntimeError("Selenium fetcher 尚未實作，請改用其他模式。")
