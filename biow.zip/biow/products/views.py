from django.db.models import Q
from django.shortcuts import get_object_or_404, render

from .models import Category, Product


def product_list(request):
    products = Product.objects.select_related('category').all()
    categories = Category.objects.all()
    selected_category = request.GET.get('category')
    query = request.GET.get('q', '').strip()

    if selected_category:
        products = products.filter(category_id=selected_category)
    if query:
        products = products.filter(
            Q(name__icontains=query)
            | Q(sku__icontains=query)
            | Q(cas_number__icontains=query)
            | Q(description__icontains=query)
            | Q(keywords__icontains=query)
        )

    return render(
        request,
        'products/list.html',
        {
            'products': products,
            'categories': categories,
            'selected_category': selected_category,
            'query': query,
        },
    )


def product_detail(request, pk):
    product = get_object_or_404(Product.objects.select_related('category'), pk=pk)
    return render(request, 'products/detail.html', {'product': product})
