#!/usr/bin/env bash
#
# Helper script to launch Gunicorn for the BioChem project.
# Intended to be called by systemd or manually during deployment.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"
VENV_PATH="${VENV_PATH:-${PROJECT_ROOT}/venv}"
SOCK_DIR="${SOCK_DIR:-/run/bioweb}"
LOG_DIR="${LOG_DIR:-${PROJECT_ROOT}/logs}"
DJANGO_SETTINGS_MODULE="${DJANGO_SETTINGS_MODULE:-bioweb.settings}"
USER="${GUNICORN_USER:-www-data}"
GROUP="${GUNICORN_GROUP:-www-data}"
WORKERS="${GUNICORN_WORKERS:-3}"
THREADS="${GUNICORN_THREADS:-2}"
BIND="${GUNICORN_BIND:-unix:${SOCK_DIR}/gunicorn.sock}"
TIMEOUT="${GUNICORN_TIMEOUT:-60}"

export DJANGO_SETTINGS_MODULE
export PYTHONPATH="${PROJECT_ROOT}:${PYTHONPATH:-}"

mkdir -p "${SOCK_DIR}" "${LOG_DIR}"
chown "${USER}:${GROUP}" "${SOCK_DIR}"

exec "${VENV_PATH}/bin/gunicorn" \
  bioweb.wsgi:application \
  --name bioweb \
  --workers "${WORKERS}" \
  --threads "${THREADS}" \
  --bind "${BIND}" \
  --timeout "${TIMEOUT}" \
  --log-level info \
  --access-logfile "${LOG_DIR}/gunicorn.access.log" \
  --error-logfile "${LOG_DIR}/gunicorn.error.log"
