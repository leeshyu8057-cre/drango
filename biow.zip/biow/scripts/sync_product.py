#!/usr/bin/env python3
"""
Interactive script to trigger the admin crawler sync from the command line.

Usage:
    python scripts/sync_product.py --url <ChemicalBook URL> --mode curl_cffi --sku CUSTOMSKU
"""
import os
import sys
import django
import argparse


PROJECT_ROOT = os.path.dirname(os.path.dirname(__file__))
sys.path.append(PROJECT_ROOT)
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'bioweb.settings')
django.setup()

from django.contrib.auth import get_user_model  # noqa: E402
from products.admin import ProductAdmin  # noqa: E402
from django.contrib import admin  # noqa: E402
from django.test import RequestFactory  # noqa: E402
from products.models import Product  # noqa: E402


def main():
    parser = argparse.ArgumentParser(description='Trigger product sync via admin logic.')
    parser.add_argument('--url', required=True, help='ChemicalBook product URL')
    parser.add_argument('--mode', default='requests', choices=['requests', 'curl_cffi', 'selenium'])
    parser.add_argument('--sku', help='Override SKU')
    parser.add_argument('--category', help='Existing category name')
    parser.add_argument('--username', default='admin')
    args = parser.parse_args()

    User = get_user_model()
    user = User.objects.filter(username=args.username).first()
    if not user:
        sys.exit(f'Cannot find admin user "{args.username}"')

    rf = RequestFactory()
    data = {'url': args.url, 'fetch_mode': args.mode}
    if args.sku:
        data['sku'] = args.sku
    if args.category:
        from products.models import Category
        cat = Category.objects.filter(name=args.category).first()
        if not cat:
            sys.exit(f'Category "{args.category}" not found.')
        data['category'] = cat.id

    request = rf.post('/admin/products/product/sync-from-url/', data=data)
    request.user = user

    admin_site = admin.site
    product_admin = ProductAdmin(Product, admin_site)
    response = product_admin.sync_product_from_url(request)
    if response.status_code == 302:
        print('Sync triggered; check ProductSyncLog for details.')
    else:
        print('Response status:', response.status_code)


if __name__ == '__main__':
    main()
