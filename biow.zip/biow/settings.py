from pathlib import Path

# === 基本設定 ===
BASE_DIR = Path(__file__).resolve().parent.parent

SECRET_KEY = 'replace-this-with-your-own-secret-key'
DEBUG = True

# 若部署到生產環境，請將 '*' 改為實際網域，例如 ['bioweb.fr']
ALLOWED_HOSTS = ['*']

# === 應用程式 (Apps) ===
INSTALLED_APPS = [
    # Django 內建應用
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'contact', 


    # 自訂應用
    'products',  # 你自己的商品 app
]

# === 中介層 (Middleware) ===
MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

# === URL 與 WSGI ===
ROOT_URLCONF = 'bioweb.urls'
WSGI_APPLICATION = 'bioweb.wsgi.application'

# === 模板設定 (Templates) ===
TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [BASE_DIR / 'bioweb' / 'templates'],  # 你可以在 
bioweb/templates 放主要模板
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
        },
    },
]

# === 資料庫設定 ===
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': BASE_DIR / 'db.sqlite3',
    }
}

# === पास驗證 (開發階段可留空) ===
AUTH_PASSWORD_VALIDATORS = [
    # 範例: {'NAME': 
'django.contrib.auth.password_validation.UserAttributeSimilarityValidator'},
]


# === 語系與時區 ===
LANGUAGE_CODE = 'zh-hant'
TIME_ZONE = 'Asia/Taipei'
USE_I18N = True
USE_TZ = True

# === 靜態與媒體檔案 ===
STATIC_URL = '/static/'
STATICFILES_DIRS = [BASE_DIR / 'static']   # 你可以放置 /static/css, 
/static/js 等資料夾

MEDIA_URL = '/media/'
MEDIA_ROOT = BASE_DIR / 'media'           # 上傳圖片儲存路徑

# === 預設主鍵型別 ===
DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'

# === 其他建議（可視情況啟用） ===
# LOGIN_URL = '/login/'
# LOGIN_REDIRECT_URL = '/'
# LOGOUT_REDIRECT_URL = '/'

# === 日後可擴充部分 ===
# 1. EMAIL_BACKEND (若要發通知信)
# 2. PAYPAL_CLIENT_ID / PAYPAL_SECRET (金流整合)
# 3. CRISP/Tawk.to 嵌入代碼可放於 base.html
